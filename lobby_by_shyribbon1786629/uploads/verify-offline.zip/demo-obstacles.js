/* Authored demo obstacles, NOT recovered Roblox place data or a physics solver.
 * The simple step/contact/seat adapters exist so the browser demo is usable. */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.DemoObstacles=factory();})(typeof globalThis!=='undefined'?globalThis:this,function(){
 'use strict';
 const stairs=Array.from({length:6},(_,i)=>({center:[-5,(i+1)*.375,-7-i*2],size:[10,(i+1)*.75,2],top:(i+1)*.75}));
 const chair={center:[6,-5],seatTop:1.8,yaw:0,triggerHalf:[1.2,1.2],parts:[
  {center:[6,1.65,-5],size:[3.5,.3,3.5]},
  {center:[4.65,.75,-6.35],size:[.3,1.5,.3]}, {center:[7.35,.75,-6.35],size:[.3,1.5,.3]},
  {center:[4.65,.75,-3.65],size:[.3,1.5,.3]}, {center:[7.35,.75,-3.65],size:[.3,1.5,.3]},
  {center:[6,3.15,-6.6],size:[3.5,2.7,.3]}
 ]};
 function inside(x,z,part){return Math.abs(x-part.center[0])<=part.size[0]/2&&Math.abs(z-part.center[2])<=part.size[2]/2}
 function stairTop(x,z){let height=null;for(const step of stairs)if(inside(x,z,step))height=Math.max(height===null?-Infinity:height,step.top);return height}
 function blocked(x,z,footY,grounded){const top=stairTop(x,z);return top!==null&&top>footY+(grounded?.751:0)+1e-6}
 function seatCandidate(x,z,footY,grounded,cooldown){return grounded&&cooldown<=0&&footY<=chair.seatTop&&Math.abs(x-chair.center[0])<=chair.triggerHalf[0]&&Math.abs(z-chair.center[1])<=chair.triggerHalf[1]}
 return Object.freeze({stairs,chair,stairTop,blocked,seatCandidate});
});
