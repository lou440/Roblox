/* Authored training dummy and approximate swept-segment contact adapter.
 * Its location, geometry, respawn and collision tests are NOT WebClient data. */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory(require('./linked-sword-hit'));else root.DemoTarget=factory(root.LinkedSwordHit);})(typeof globalThis!=='undefined'?globalThis:this,function(Hit){
 'use strict';
 const center=[10,0,-5],maxHealth=100;
 const parts=[
  {name:'Torso',center:[10,3,-5],size:[2,2,1]},
  {name:'Head',center:[10,4.5,-5],size:[2,1,1]},
  {name:'Left Arm',center:[8.5,3,-5],size:[1,2,1]},
  {name:'Right Arm',center:[11.5,3,-5],size:[1,2,1]},
  {name:'Left Leg',center:[9.5,1,-5],size:[1,2,1]},
  {name:'Right Leg',center:[10.5,1,-5],size:[1,2,1]}
 ];
 function point(m,p){return [0,1,2].map(i=>m[i]*p[0]+m[4+i]*p[1]+m[8+i]*p[2]+m[12+i])}
 // Conservative half-stud expansion approximates the public Handle Size X=1;
 // rotated box contacts and Roblox physics are not recovered.
 function segmentBox(a,b,part,radius=.5){
  let lo=0,hi=1;for(let i=0;i<3;i++){
   const min=part.center[i]-part.size[i]/2-radius,max=part.center[i]+part.size[i]/2+radius,d=b[i]-a[i];
   if(Math.abs(d)<1e-9){if(a[i]<min||a[i]>max)return false;continue}
   let t0=(min-a[i])/d,t1=(max-a[i])/d;if(t0>t1)[t0,t1]=[t1,t0];lo=Math.max(lo,t0);hi=Math.min(hi,t1);if(lo>hi)return false;
  }return true;
 }
 function create(){
  const state={health:maxHealth,hits:0,lastDamage:0,lastContactTime:null,creatorExpires:null,respawnAt:null,overlap:false,lastBlade:null};
  let previous=null,tag=null,now=0;
  const owner={Neutral:true,TeamColor:'local'},handle={},arm={},grip={Part0:arm,Part1:handle};
  arm.FindFirstChild=n=>n==='RightGrip'?grip:null;
  const humanoid={GetChildren:()=>tag?[tag]:[],TakeDamage(n){state.health=Math.max(0,state.health-n);state.lastDamage=n;state.hits++;state.lastContactTime=now;if(state.health===0)state.respawnAt=now+5}};
  const target={FindFirstChild:n=>n==='Humanoid'?humanoid:null};
  const ctx={hit:{Parent:target},CheckIfAlive:()=>true,Character:{FindFirstChild:n=>n==='Right Arm'?arm:null},Handle:handle,Player:owner,Players:{GetPlayerFromCharacter:()=>null},Damage:5,
   Instance:{new:()=>{const v={IsA:n=>n==='ObjectValue',Destroy(){if(tag===v)tag=null},SetParent(h){if(h!==humanoid)throw Error('invalid demo humanoid');tag=v}};return v}},
   Debris:{AddItem:(value,t)=>{state.creatorExpires=now+t}}};
  function reset(){Object.assign(state,{health:maxHealth,hits:0,lastDamage:0,lastContactTime:null,creatorExpires:null,respawnAt:null,overlap:false,lastBlade:null});previous=null;tag=null}
  function step(t,frame,sword){
   now=t;if(state.creatorExpires!==null&&t>=state.creatorExpires){tag=null;state.creatorExpires=null}
   if(state.respawnAt!==null&&t>=state.respawnAt)reset();
   if(!frame||!sword||!sword.equipped||state.health<=0){state.overlap=false;previous=null;state.lastBlade=null;return false}
   // The blade occupies approximately z=-1.98..2.39 in the public mesh.
   const a=point(frame,[0,0,-1.98]),b=point(frame,[0,0,2.39]);
   const overlaps=(x,y)=>parts.some(part=>segmentBox(x,y,part));
   const direct=overlaps(a,b),swept=!!previous&&(overlaps(previous.a,a)||overlaps(previous.b,b));
   const newlyTouching=(direct||swept)&&!state.overlap;previous={a,b};state.lastBlade={a,b};state.overlap=direct;
   if(newlyTouching){ctx.Damage=sword.damage;return Hit.blow(ctx)}return false;
  }
  return Object.freeze({step,reset,getState:()=>({...state,center:[...center],parts:parts.map(p=>({name:p.name,center:[...p.center],size:[...p.size]})),maxHealth,source:'authored dummy; swept blade/AABB contact and respawn are browser approximations'})});
 }
 return Object.freeze({center,parts,maxHealth,point,segmentBox,create});
});
