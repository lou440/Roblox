# R6 appearance: sources and boundaries

This page is a partial, offline research demo, **not** a reconstruction of the Roblox humanoid or its physics. The public archive cited below contains a byte-identical copy of the original 1142 `WebClient.wasm`; that original owner folder lacked the referenced model, face and animations. A later read-only scan of the owner's updated 1145 download found the R6 model and face with hashes matching the archive. The public animation responses and candidate rig remain separately sourced.

## Static part data

`archived-r6-parts.js` is generated from `content/avatar/characterR6NoFace.rbxm` in the matching-WASM public archive, SHA256 `705d99fba99384fb21b701774072f9f40f7edd674585348c9baf07ca3c9d2b26`. It contains the following torso-relative positions and sizes. The archived root is invisible and all four limbs have `CanCollide = false`; the head and torso have `CanCollide = true` in the static model. The demo does **not** simulate those part collisions.

| Part | Size | Torso-relative position |
| --- | --- | --- |
| Head | (2, 1, 1) | (0, 1.5, 0) |
| Torso | (2, 2, 1) | (0, 0, 0) |
| Left Arm | (1, 2, 1) | (-1.5, 0, 0) |
| Right Arm | (1, 2, 1) | (1.5, 0, 0) |
| Left Leg | (1, 2, 1) | (-0.5, -2, 0) |
| Right Leg | (1, 2, 1) | (0.5, -2, 0) |
| HumanoidRootPart | (2, 2, 1) | (0, 0, 0) |

The part offsets are computed in the archived torso's local coordinate frame, not assumed from its world coordinates. The model contains **no Motor6D joints**. It uses BrickColor 194, not the classic noob palette; the demo's yellow, blue and green colors are an explicit appearance choice.

## Head and face

The model's `Head` has a `SpecialMesh` with MeshId `18446596298`, scale `(1, 1, 1)` and texture `rbxasset://textures/face.png`. `linked-r6-head-mesh.js` embeds the current public GET response for that MeshId, SHA256 `ecdbdfd9aa91ce26d87d382a3653738cf6d5a81fc5b7aff1b02e8a403451be98` (426 vertices, 720 triangles). The response is linked by the archived model, but is not an individually verified owner file or proof of the asset's bytes at the original build date. Its positions, normals, UVs and indices were compared with the downloaded binary.

`archived-r6-face.js` embeds the archived 128×128 `face.png`, SHA256 `a45ca21d310953cb2bb68608f02b6a24a4ad6f6e833a328cbd4e13328475d692`; the same hash also appeared in an official Player package and at the current official WebClient CDN. The separate `assets/face.png` is the identical image. The renderer uses those UVs and image, but its shading, composition and heading are demo choices, not the recovered WebClient renderer.

The owner's distinct `content/avatar/heads/head.mesh` remains embedded in `target-head-mesh.js` and was independently compared against the provided file; it has SHA256 `c192daeba6265e9ab13a6d5132e9f1e496532e51708b1a5cb13e5ae917673976`, 517 vertices, and 846 triangles. It is **not** the head currently displayed.

## Candidate rig, animation and movement

A separate matching-WASM public archive file, `content/avatar/morpherEditorR6.rbxmx`, SHA256 `a68019d9b9b34e74fba246aec5510249cb69599029df3eb3cb5eee96dcbfc98e`, supplies six `Motor6D` parent/child links and their `C0`/`C1` coordinate frames. It was not present at the checked owner path. `r6-animation-data.js` and `r6-animation-walk-data.js` embed those frames and the decoded poses. For each joint, the browser composes `Part1 = Part0 * C0 * PoseTransform * inverse(C1)`; a separate NumPy check compared 154 part matrices across all 22 walk frames against the archived XML and decoded raw poses. Rest-pose part centers also match the archived part layout.

The archived `content/avatar/unification/humanoidAnimateR6WithFace.rbxm` contains an Animate LocalScript whose source SHA256 is `aed38fe1363162a352140be6db861fdcf41ba5383f2ac7f268df0dd93ff4b4ca`. Its `onRunning` chooses walk when speed divided by rig scale is greater than `0.01`, uses a `0.1`-second transition, and adjusts the standard `180426354` walk track by `(speed / rig scale) / 14.5`. Otherwise it chooses idle unless an emote is active. The selected rule matched the archived source under official Luau 0.745 in 40,016 mocked cases. The demo uses rig scale 1 and feeds 16 to the walk animation while moving. The value 16 is the `WalkSpeed` serialized in the owner’s downloaded 1145 `characterR6NoFace.rbxm` Humanoid, not evidence that the browser adapter reproduces the Humanoid controller.

The displayed walk uses current public asset `180426354`, SHA256 `b4d5cca77daaac4c3e28629f7bff0bbb97a67ca4ad150ee78a767c99bac57a44`: 22 keyframes over approximately 0.667 seconds. Idle uses asset `180435571`, SHA256 `ce4d11f42a49d4697fb44e4a32d7334684d58d0f5e6db31d031390df2e3707a4`: 21 keyframes over 1 second. The source also randomly selects a second idle asset, which this demo does not implement. Current public asset bytes cannot be proven to be the original historical bytes or the owner’s active animation branch.

The browser adapter linearly interpolates positions and uses quaternion slerp and a `0.1`-second crossfade. These interpolation, blend, looping and renderer implementations have **not** been compared with Roblox Animator. The referenced jump, fall, sit, tool-hold, slash and lunge clips are also sampled by the adapter; full Humanoid animation states are not implemented. Keyboard/touch movement, speed, gravity, jump, collision response and locomotion physics remain independently authored approximations; using archived walk poses does **not** recover Roblox walking physics.

## Isolated Running-state height calculation

The supplied WASM's `37108` Running-state path calls `37075`, which calls `37057` and seven small helpers. The page's `running-height-program.js` retains those nine original instruction streams and `running-physics-vm.js` interprets their restricted instruction set in JavaScript. Against an isolated module of the nine extracted WASM functions, 100,000 randomized synthetic-memory cases matched, including root/leg pointers, sentinel values, special floats and both `owner+308` branches; there were no mocked calls in that comparison.

The separate `running-height-adapter.js` constructs a **synthetic** R6-shaped object image using the archived root and leg sizes, selects `owner+308=0`, chooses offset `owner+264=0`, and supplies the demo's floor height. In that selected branch, the calculation combines half the root part's clamped Y size with the larger leg Y size and the offset; for a floor at zero and the archived dimensions it yields 3 studs. The demo compares its root reference to that target when applying its existing ground cutoff. This does not identify the owner's runtime flags or prove that the synthetic object image matches the real engine state.

A broader research-only chain containing 25 extracted functions, including `37108`, `37123`, `37036` and `37075`, matched 40,000 synthetic cases with collision identity, frame-cache updates, slope limit, alternate surface, ground lookup, virtual call and initialization locks **mocked**. That chain is not connected to the demo. Ground detection, contact impulses, solver, character controller, horizontal motion, gravity, jump and the animation system remain unrecovered; the demo's grounded decision and response are independently authored.

## Additional action clips and authored scene

The current public clips are jump `14464997074` (19 frames, 0.625 s), fall `14464364913` (14, 0.65 s), sit `178130996` (2, 2 s), hold `182393478` (3, 0.5 s), slash `129967390` (4, 0.5 s), and lunge `129967478` (3, 1.5 s). Tests checked 258 decoded pose samples. The script-derived selected transitions use a 0.3 s jump timer, 0.3 s fall transition, 0.5 s sit transition and 0.3 s toolanim timeout; blending and priority are browser approximations, not verified Animator behavior. The six-step staircase, chair, automatic sit/stand proximity logic and gray training dummy are authored scene elements. Contacts, step-up, seat welding and target health are not recovered Roblox physics.

## Default parameters and sword motion correction

A read-only check of the owner's 1145 `content/avatar/characterR6NoFace.rbxm` confirmed SHA256 `705d99fba99384fb21b701774072f9f40f7edd674585348c9baf07ca3c9d2b26`. Its `Humanoid` explicitly serializes `WalkSpeed = 16`, `JumpPower = 50`, and `HipHeight = 0`. The demo now uses the first two values. It uses `196.2` studs/s² from the [documented Workspace gravity default](https://robloxapi.github.io/ref/class/Workspace.html); the original place's gravity was not recovered and can differ. The 240 Hz semi-implicit integration, immediate horizontal control, stairs, collision and character contact remain independently written approximations, **not** the WebClient physics solver.

The selected public Linked Sword script requests a `BodyVelocity` of `(0,10,0)` with `MaxForce = (0,4000,0)` for 0.5 s. A target velocity is not a direct instantaneous velocity assignment. The previous demo incorrectly clamped vertical velocity to 10 even on the ground. The corrected demo never launches or adds horizontal force from sword activation while grounded; while falling in the air during the source-script lunge window it applies an authored 0.8 gravity factor for a small glide. That factor is a user-directed approximation, **not** recovered Roblox BodyVelocity, mass, contact or Humanoid physics. Different published sword scripts vary; this is not proof of the owner's original item or behavior.
