/* DOM bridge for selected candidate Roblox BackpackScript bytecode. The Tool,
 * Humanoid, character, input and GUI services are offline mocks. The extracted
 * layouts and normal-tool selection execute the compiled candidate code. */
(() => {
 'use strict';
 const $=id=>document.getElementById(id),engine=window.RobloxBackpackResearch,program=window.RobloxBackpackProgram,data=window.LinkedSwordData;
 const host=$('rbx-backpack'),hotbar=$('rbx-hotbar'),inventory=$('rbx-backpack-inventory'),arrow=$('rbx-backpack-open');
 if(!host||!hotbar||!inventory||!arrow||!engine||!program||!data)throw Error('Backpack bridge did not load');
 const search=$('rbx-backpack-search'),arrowImg=arrow.querySelector('img');arrowImg.src=window.RobloxBackpackArrow;$('rbx-more-inventory-icon').src=window.RobloxInventoryIcon;
 let isOpen=false,equipped=false,last=null;
 const coarse=()=>matchMedia('(pointer:coarse)').matches||navigator.maxTouchPoints>0;
 function dims(el,size,pos){el.style.width=`calc(${size.X.Scale*100}% + ${size.X.Offset}px)`;el.style.height=`calc(${size.Y.Scale*100}% + ${size.Y.Offset}px)`;el.style.left=`calc(${pos.X.Scale*100}% + ${pos.X.Offset}px)`;el.style.top=`calc(${pos.Y.Scale*100}% + ${pos.Y.Offset}px)`}
 function render(){
  const phone=coarse()&&innerWidth<1024,n=phone?3:10,tools=Array.from({length:n},(_,i)=>i===0);
  last=engine.layout(program,{phone,numberOfSlots:n,inventoryRows:phone?2:4,tools,inventoryOpen:isOpen});
  dims(hotbar,last.hotbar.Size,last.hotbar.Position);dims(inventory,last.inventory.Size,last.inventory.Position);inventory.hidden=!isOpen;
  arrow.hidden=!last.button.Visible;arrow.style.left=`calc(${last.button.Position.X.Scale*100}% + ${last.button.Position.X.Offset}px)`;arrow.style.top=`calc(${last.button.Position.Y.Scale*100}% + ${last.button.Position.Y.Offset}px)`;
  const slots=[];
  for(let i=0;i<n;i++){
   const slot=last.slots[i],button=document.createElement('button');button.type='button';button.className='rbx-backpack-slot';button.hidden=!slot.visible;button.dataset.slot=String(i+1);
   button.setAttribute('aria-label',i===0?`Slot 1: ${data.toolName}${equipped?', equipped':''}`:`Empty slot ${i+1}`);button.setAttribute('aria-pressed',String(i===0&&equipped));
   button.disabled=i!==0;button.style.width=last.iconSize+'px';button.style.height=last.iconSize+'px';
   if(slot.position){button.style.left=slot.position.X.Offset+'px';button.style.top=slot.position.Y.Offset+'px'}
   if(i===0){const img=document.createElement('img');img.src=data.iconData;img.alt='';button.append(img);button.addEventListener('click',()=>select())}
   if(!coarse()){const number=document.createElement('span');number.className='rbx-slot-number';number.textContent=String(i===9?0:i+1);button.append(number)}
   slots.push(button);
  }
  hotbar.replaceChildren(...slots);
 }
 function select(processed=false){
  const result=engine.tool(program,{initial:equipped?'character':'backpack',processed,hasTool:true});equipped=result.parent==='character';render();window.dispatchEvent(new CustomEvent('backpack:changed',{detail:{equipped,isOpen}}));
 }
 // Opening inventory is non-modal: do not discard a held movement key.
 function setOpen(value){isOpen=!!value;if(!isOpen){search.value='';if(document.activeElement===search)search.blur()}render();window.dispatchEvent(new CustomEvent('backpack:changed',{detail:{equipped,isOpen}}));}
 function toggle(){setOpen(!isOpen)}
 arrow.addEventListener('click',toggle);search.addEventListener('focus',()=>window.dispatchEvent(new Event('hud:control-suspend')));
 document.addEventListener('keydown',e=>{
  if(e.repeat||e.ctrlKey||e.metaKey||e.altKey)return;
  const editing=!!(e.target&&e.target.closest&&e.target.closest('input,textarea,select,[contenteditable="true"]'));
  const menu=!!(window.__hudInteraction&&window.__hudInteraction.getState().menuOpen);
  if(e.key==='Escape'&&isOpen&&!menu){if(editing){search.value='';search.blur()}else setOpen(false);e.preventDefault();e.stopImmediatePropagation();return}
  if(editing||menu)return;
  if(e.code==='Backquote'){toggle();e.preventDefault();e.stopImmediatePropagation();return}
  if(e.code==='Digit1'){select();e.preventDefault();e.stopImmediatePropagation()}
 },true);
 window.addEventListener('resize',render);window.addEventListener('hud:menu-open',()=>{if(isOpen)setOpen(false)});
 window.__robloxBackpack=Object.freeze({toggle,setOpen,select,unequip(){if(equipped){equipped=false;render();window.dispatchEvent(new CustomEvent('backpack:changed',{detail:{equipped,isOpen}}))}},getState(){return{isOpen,equipped,toolName:data.toolName,assetId:data.assetId,iconAssetId:data.iconAssetId,source:'compiled BackpackScript matches owner 1145 patch; engine services mocked',owner1145ModuleHashVerified:true,original1142PatchVerified:false,layout:last}}});
 render();
})();
