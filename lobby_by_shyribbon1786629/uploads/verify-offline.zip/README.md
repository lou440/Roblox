# Offline Baseplate — research build

This is a **partial research demo**, not a JavaScript recreation of the complete WebClient engine. It combines a few bytecode-derived routines with the earlier independent demo. The renderer, movement, player, physics, lighting, and scene layout are still approximations. The demo baseplate configuration is hand-authored; it is not a place recovered from the WASM.

## Run

Open `index.html` in a recent Chrome, Edge, or Firefox with WebGL enabled. Everything is local: no server, npm, network connection, external assets, or running WebAssembly is required.

## What is connected

- **HUD (partial):** selected candidate compiled menu/chat/settings instructions run through a restricted interpreter alongside a health-bar model. Selected Settings and Backpack modules also match the owner’s updated 1145 patch; the original 1142 owner patch was absent. Menu pages, reset, unsupported settings and local-only chat are partial browser adapters—not reconstructed Roblox services. The active target branch and original complete menu behavior are unknown; the health bar is not connected to a recovered Humanoid. See `HUD_PROVENANCE.md`.

- **R6 appearance (partial):** the seven static part sizes, relative positions, and referenced head scale come from the public archive associated with the exact same WASM. The displayed head is the current public response for the archive model's MeshId, and its face texture matches the archive and an official WebClient package. The original 1142 folder lacked the model and face; the updated 1145 download contains matching hashes. Six candidate archive Motor6D frames and referenced walk/idle/jump/fall/sit/tool keyframes drive limb motion, with browser interpolation. Noob colors, heading, renderer, movement and physics remain demo choices. The separately supplied head mesh remains available for research but is not displayed. See `R6_PROVENANCE.md`.

- **R6 Running height fragment:** nine recovered WASM functions execute as JavaScript instructions to calculate a target using a synthetic R6 object image and the demo floor. Their 3-stud result is used by the demo's ground cutoff. Ground detection and response, walking motion and the physics solver remain approximations—not Roblox physics. See `R6_PROVENANCE.md`.
- **Backpack and item (partial):** selected `BackpackScript` bytecode matching the owner’s updated 1145 patch drives a hotbar and one public Linked Sword. Click slot 1 or press **1** to equip, then click or tap the scene to swing; two quick activations trigger a lunge. The sword can hit an authored training dummy. Sword contact, damage, weld, animation and rendering are browser adapters, not Roblox physics or multiplayer combat. Grounded lunges do not launch the player; the small airborne glide is an authored approximation. Drop and replication are not implemented. See `BACKPACK_PROVENANCE.md`.
- **Block geometry:** corner positions, face order and normals, half-diagonal, and rotated half-extents are translated from traced instructions and data. A restricted projection-inside-Block-face query is also translated and used for the top-face footprint check. The height test, contact response, quad-to-triangle conversion and WebGL shader are independent demo choices, not recovered collisions.
- **Part dimensions and material:** the detached-primitive size rules, Block volume/center, material selection, and a restricted normal update path are translated. One callback is handled only for this unlinked primitive; locking and allocation are mocked, and attached-world, custom-shape and other engine branches are not implemented.
- **SpawnLocation:** constructor property defaults and selected property-state behavior are translated. The demo does not reproduce actual spawning or team logic.
- **Keyboard input:** key-code mapping, keyboard record creation, ring control, a restricted normal dispatcher/vector path and modifier-mask updates use traced instructions. The pre-resolved object-update tail of 99505 is also translated, with synthetic per-key objects and mocked setters, notifications and signals. Lookup, ownership, locking and the later record-to-demo-controls adapter are demo choices; touch input and movement are not the original gameplay consumer.
- **Frame-step accounting:** a restricted normal branch of target function 89079 calculates the number of demo updates, retained fractional steps and dropped backlog. The page selects a 240 Hz demo frequency and zero for the cap setting; these are demo inputs, not verified target defaults. Each tick still runs the approximate character physics, not WebClient physics.
- **Asset staging:** the local, hand-authored scene description is staged with a partial port of the original inline-file/asset registry routines. Reading it back through the port's JavaScript snapshot is demo glue, not a recovered file-read function.

See `ANALYSIS.md` for function numbers, test scope, and limitations. The original WASM is not included or executed by the page.

## Controls

- **W A S D** or arrow keys: move relative to the camera
- **Space**: jump
- **Drag** the scene: orbit the camera
- **Mouse wheel**: zoom
- **Escape**, then **R** or **Reset Character**: confirm a reset to the starting point
- **1** or hotbar slot 1: equip/unequip the Linked Sword
- **Left click/tap**: swing; two quick clicks: lunge. Walk near the gray dummy to test hits.
- Walk into the chair to sit; **Space** stands up. Walk up the stairs.
- Settings → **Volume** controls the embedded sword sounds.
- **`** or More → Inventory: open/close the backpack
- **Escape**: open or close the local menu; **/**: open local chat
- **Chat** sends messages only to this local session—there is no server or other player.

Touch controls appear on touch-first devices. Walking off the demo plate resets the character; this behavior is not claimed to match WebClient.
