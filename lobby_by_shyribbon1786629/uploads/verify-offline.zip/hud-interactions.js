/* Offline HUD interaction adapters inspired by archived CoreScripts. They
 * provide local behavior, not Roblox services or a verified target menu branch. */
(() => {
 'use strict';
 const $=id=>document.getElementById(id),ui=window.RobloxRecoveredUI,programs=window.RobloxRecoveredUIPrograms,visual=window.RobloxChatVisualResearch;
 const menuButton=$('rbx-menu-button'),moreButton=$('rbx-more-button'),chatButton=$('rbx-chat-button');
 const overlay=$('rbx-menu-overlay'),dialog=overlay.querySelector('.rbx-menu-dialog'),confirm=$('rbx-reset-confirm');
 const more=$('rbx-more-panel'),chat=$('rbx-chat-panel'),input=$('rbx-chat-input'),messages=$('rbx-chat-messages');
 const slider=$('rbx-sensitivity'),sliderValue=$('rbx-sensitivity-value');
 if(!ui||!programs||!visual)return;
 let menuOpen=false,moreOpen=false,chatOpen=false,resetOpen=false,page='people',messageCount=0;
 let sensitivity=ui.graphics.guiToEngine(programs.graphics,Number(slider.value));
 const suspend=()=>window.dispatchEvent(new Event('hud:control-suspend'));
 function setChat(open,focus=false){
  chatOpen=!!open;chat.hidden=!chatOpen;chatButton.setAttribute('aria-expanded',String(chatOpen));document.body.classList.toggle('hud-chat-open',chatOpen);
  $('rbx-chat-icon').textContent=(chatOpen?visual.activeMigration:visual.inactiveMigration).name;
  if(chatOpen&&focus){suspend();input.focus()}else if(!chatOpen&&document.activeElement===input){input.blur()}
 }
 function setMore(open){moreOpen=!!open;more.hidden=!moreOpen;moreButton.setAttribute('aria-expanded',String(moreOpen))}
 function setPage(name){
  if(!['people','settings','help'].includes(name))return;page=name;
  for(const tab of document.querySelectorAll('[data-rbx-tab]')){const selected=tab.dataset.rbxTab===name;tab.setAttribute('aria-selected',String(selected));$(tab.getAttribute('aria-controls')).hidden=!selected;if(selected)tab.scrollIntoView({block:'nearest',inline:'nearest'})}
 }
 function showReset(open){resetOpen=!!open;confirm.hidden=!resetOpen;if(resetOpen){suspend();$('rbx-reset-cancel').focus()}else if(menuOpen)$('rbx-menu-reset').focus()}
 function setMenu(open,tab='people'){
  menuOpen=!!open;overlay.hidden=!menuOpen;document.body.classList.toggle('hud-menu-open',menuOpen);menuButton.setAttribute('aria-expanded',String(menuOpen));
  if(menuOpen){setMore(false);setPage(tab);suspend();window.dispatchEvent(new Event('hud:menu-open'));dialog.focus()}else{showReset(false);menuButton.focus({preventScroll:true})}
 }
 menuButton.addEventListener('click',()=>setMenu(!menuOpen));
 moreButton.addEventListener('click',()=>setMore(!moreOpen));
 chatButton.addEventListener('click',()=>setChat(!chatOpen,true));
 $('rbx-menu-resume').addEventListener('click',()=>setMenu(false));
 $('rbx-menu-reset').addEventListener('click',()=>showReset(true));$('rbx-reset-cancel').addEventListener('click',()=>showReset(false));
 $('rbx-reset-confirm-button').addEventListener('click',()=>{if(window.__baseplate)window.__baseplate.reset();showReset(false);setMenu(false)});
 overlay.addEventListener('click',e=>{if(e.target===overlay)setMenu(false)});
 for(const tab of document.querySelectorAll('[data-rbx-tab]'))tab.addEventListener('click',()=>setPage(tab.dataset.rbxTab));
 for(const button of more.querySelectorAll('[data-rbx-more]'))button.addEventListener('click',()=>{
  const action=button.dataset.rbxMore;setMore(false);
  if(action==='inventory'&&window.__robloxBackpack)window.__robloxBackpack.toggle();
 });
 document.addEventListener('pointerdown',e=>{if(moreOpen&&!more.contains(e.target)&&!moreButton.contains(e.target))setMore(false)});
 function setSensitivity(value){sensitivity=value;sliderValue.textContent=sensitivity.toFixed(2);window.dispatchEvent(new CustomEvent('hud:sensitivity-changed',{detail:{value:sensitivity}}))}
 slider.addEventListener('input',()=>{const value=Number(slider.value);setSensitivity(ui.graphics.guiToEngine(programs.graphics,value))});
 window.addEventListener('hud:sensitivity-input',e=>{const match=String(e.detail&&e.detail.text||'').match(/[0-9.]+/),n=match?Number(match[0]):NaN;if(!Number.isFinite(n)){setSensitivity(sensitivity);return}const value=Math.max(.001,Math.min(100,Math.abs(n)));slider.value=String(Math.max(0,Math.min(10,ui.graphics.engineToGui(programs.graphics,value))));setSensitivity(value)});
 input.addEventListener('focus',suspend);
 $('rbx-chat-form').addEventListener('submit',e=>{
  e.preventDefault();const text=input.value.trim();if(!text)return;
  const row=document.createElement('li'),author=document.createElement('span'),body=document.createElement('span');
  author.className='rbx-chat-author';author.textContent='[You]: ';body.textContent=text;row.append(author,body);messages.append(row);messageCount++;input.value='';
  while(messages.children.length>81)messages.children[1].remove();messages.scrollTop=messages.scrollHeight;input.focus();
 });
 document.addEventListener('keydown',e=>{
  if(e.repeat||e.ctrlKey||e.metaKey||e.altKey)return;
  const typing=!!(e.target&&e.target.closest&&e.target.closest('input,textarea,select,[contenteditable="true"]'));
  if(e.key==='Escape'){
   if(resetOpen)showReset(false);else if(menuOpen)setMenu(false);else if(moreOpen)setMore(false);else if(typing&&chatOpen)setChat(false);else setMenu(true);
   e.preventDefault();e.stopImmediatePropagation();return;
  }
  if(menuOpen&&e.code==='KeyR'&&!typing){showReset(true);e.preventDefault();e.stopImmediatePropagation();return}
  if(!menuOpen&&!typing&&e.key==='/'){setChat(true,true);setMore(false);e.preventDefault();e.stopImmediatePropagation()}
 },true);
 window.__hudInteraction=Object.freeze({
  blocksGameplay(target){return menuOpen||!!(target&&target.closest&&target.closest('input,textarea,select,[contenteditable="true"]'))},
  get sensitivity(){return sensitivity},
  getState(){return{menuOpen,moreOpen,chatOpen,resetOpen,page,messageCount,sensitivity,chatTransport:'local only'}}
 });
})();
