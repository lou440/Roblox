/* Generic player-side TrussPart contact adapter. Roblox describes the Humanoid
 * Climbing state and climbable TrussParts, but its internal solver is not
 * recovered. This is authored browser physics, not code running on a ladder. */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.HumanoidClimbing=factory();})(globalThis,function(){'use strict';
 function step(player,input,dt,parts){if(player.climbCooldown>0){player.climbing=false;player.climbSpeed=0;return false}const f=input.forward||0,s=input.side||0,yaw=input.cameraYaw||0,wx=-Math.sin(yaw)*f+Math.cos(yaw)*s,wz=-Math.cos(yaw)*f-Math.sin(yaw)*s;let hit=null,best=Infinity;
  for(const part of parts||[]){if(part.type!=='TrussPart'||part.canCollide===false)continue;const [cx,cy,cz]=part.center,[sx,sy,sz]=part.size,bottom=cy-sy/2,top=cy+sy/2,dx=player.x-cx,dz=player.z-cz;if(Math.abs(dx)>sx/2+.15||Math.abs(dz)>sz/2+1.2||player.y<bottom-.1||player.y>top+.1)continue;const distance=Math.abs(dz);if(distance<best){best=distance;hit={part,bottom,top,dx,dz}}}
  if(player.climbExit){if(!hit||player.grounded||player.y<hit.top-.9)player.climbExit=false;else{player.climbing=false;player.climbSpeed=0;return false}}
  if(!hit){player.climbing=false;player.climbSpeed=0;return false}
  const len=Math.hypot(wx,wz),toward=len>0?-(wx*hit.dx+wz*hit.dz)/((Math.hypot(hit.dx,hit.dz)||1)*len):0;
  if(!player.climbing&&(f===0||(!player.grounded&&f<0)||toward<.05)){player.climbSpeed=0;return false}
  if(!f&&s){player.climbing=false;player.climbSpeed=0;return false}
  if(player.y>=hit.top-.0001&&f>0){player.climbing=false;player.climbSpeed=0;player.climbExit=true;return false}
  if(player.y<=hit.bottom&&f<0){player.climbing=false;player.climbSpeed=0;return false}
  player.climbing=true;player.climbSpeed=f*(input.walkSpeed||16)*.7;player.moving=!!f;player.vy=0;player.grounded=false;player.y=Math.max(hit.bottom,Math.min(hit.top,player.y+player.climbSpeed*dt));if(player.y<=hit.bottom){player.climbing=false;player.climbSpeed=0;player.grounded=true}return true
 }
 function jump(player,parts,power=50){if(!player.climbing)return false;let closest=null,distance=Infinity;for(const p of parts||[]){const d=Math.hypot(player.x-p.center[0],player.z-p.center[2]);if(d<distance){distance=d;closest=p}}const vx=closest?player.x-closest.center[0]:0,vz=closest?player.z-closest.center[2]:1,n=Math.hypot(vx,vz)||1;player.climbVX=vx/n*12;player.climbVZ=vz/n*12;player.climbCooldown=.45;player.climbing=false;player.climbSpeed=0;player.climbExit=false;player.grounded=false;player.vy=power;player.jumpTime=.3;return true}
 return Object.freeze({step,jump});
});
