/* Authored demo obstacles, NOT recovered Roblox place data or a physics solver.
 * The simple step/contact/seat adapters exist so the browser demo is usable. */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.DemoObstacles=factory();})(typeof globalThis!=='undefined'?globalThis:this,function(){
 'use strict';
 const stairs=Array.from({length:6},(_,i)=>({center:[-5,(i+1)*.375,-7-i*2],size:[10,(i+1)*.75,2],top:(i+1)*.75}));
 const chair={center:[6,-5],seatTop:1.8,yaw:0,triggerHalf:[1.2,1.2],parts:[
  {center:[6,1.65,-5],size:[3.5,.3,3.5]},
  {center:[4.65,.75,-6.35],size:[.3,1.5,.3]}, {center:[7.35,.75,-6.35],size:[.3,1.5,.3]},
  {center:[4.65,.75,-3.65],size:[.3,1.5,.3]}, {center:[7.35,.75,-3.65],size:[.3,1.5,.3]},
  {center:[6,3.15,-6.6],size:[3.5,2.7,.3]}
 ]};
 const platform={center:[-20,11.75,-14],size:[12,.5,10],top:12};
 const carpetPickup={center:[-20,12.4,-14],radius:2.6};
 const ladder={center:[-20,0,-9],height:12,parts:[{center:[-22,6,-9],size:[.3,12,.35]},{center:[-18,6,-9],size:[.3,12,.35]},...Array.from({length:13},(_,i)=>({center:[-20,.4+i*.9,-9],size:[4,.18,.35]}))]};
 const collisionParts=[...stairs,...chair.parts,platform,...ladder.parts];
 const climbables=[{type:'TrussPart',center:[-20,6,-9],size:[4,12,.35],canCollide:true}];
 function inside(x,z,part){return Math.abs(x-part.center[0])<=part.size[0]/2&&Math.abs(z-part.center[2])<=part.size[2]/2}
 function stairTop(x,z,footY=0){let height=null;for(const step of stairs)if(inside(x,z,step))height=Math.max(height===null?-Infinity:height,step.top);if(inside(x,z,platform)&&footY>=platform.top-.751)height=Math.max(height===null?-Infinity:height,platform.top);for(const truss of climbables){const top=truss.center[1]+truss.size[1]/2;if(footY>=top-.751&&planarDistance(x,z,truss)<.8)height=Math.max(height===null?-Infinity:height,top)}return height}
 function planarDistance(x,z,part){return Math.hypot(Math.max(0,Math.abs(x-part.center[0])-part.size[0]/2),Math.max(0,Math.abs(z-part.center[2])-part.size[2]/2))}
 function blocked(x,z,footY,grounded,oldX=x,oldZ=z){const top=stairTop(x,z,footY);if(top!==null&&top>footY+(grounded?.751:0)+1e-6)return true;for(const part of [platform,...climbables]){const bottom=part.center[1]-part.size[1]/2,upper=part.center[1]+part.size[1]/2;if(footY>=upper-.02||footY+5<=bottom+.01||footY>=upper-.751)continue;const d=planarDistance(x,z,part),old=planarDistance(oldX,oldZ,part);if(d<.8&&!(old<.8&&d>=old-1e-6))return true}return false}
 function ceiling(x,z,oldY,newY){if(newY<=oldY)return null;let hit=null;for(const part of [platform,...climbables]){const bottom=part.center[1]-part.size[1]/2;if(planarDistance(x,z,part)<.8&&oldY+5<=bottom&&newY+5>bottom)hit=hit===null?bottom-5:Math.min(hit,bottom-5)}return hit}
 function seatCandidate(x,z,footY,grounded,cooldown){return grounded&&cooldown<=0&&footY<=chair.seatTop&&Math.abs(x-chair.center[0])<=chair.triggerHalf[0]&&Math.abs(z-chair.center[1])<=chair.triggerHalf[1]}
 return Object.freeze({stairs,chair,ladder,platform,carpetPickup,collisionParts,climbables,stairTop,blocked,ceiling,seatCandidate});
});
