/* Browser approximation. */
(() => {
  'use strict';
  const canvas = document.getElementById('game');
  const errorBox = document.getElementById('error');
  const overhead=document.getElementById('rbx-dummy-overhead'), overheadHealth=document.getElementById('rbx-dummy-health'), overheadFill=document.getElementById('rbx-dummy-health-fill'),chatBubble=document.getElementById('rbx-local-chat-bubble');
  const showError = (message) => { errorBox.hidden = false; errorBox.textContent = message; };
  const gl = canvas.getContext('webgl', {alpha: true, antialias: true, depth: true}) || canvas.getContext('experimental-webgl');
  if (!gl) { showError('This browser could not start WebGL. Enable hardware acceleration, or open this file in a recent Chrome, Edge, or Firefox.'); return; }
  try {
    const Block=window.WasmBlockGeometry, BlockFaceQuery=window.WasmBlockFaceQuery, PartView=window.WasmBasePartMemoryView;
    const SpawnState=window.WasmSpawnLocationState, AssetFS=window.WasmAssetFS;
    const Chain=window.WasmPrimitiveChain, Material=window.WasmMaterialProperties;
    const DetachedUpdate=window.WasmDetachedBlockUpdate;
    const MainQueue=window.WasmMainEventQueue, Keyboard=window.WasmKeyboardCode, KeyboardInput=window.WasmKeyboardInput;
    const InputVector=window.WasmInputEventVector, InputDispatch=window.WasmInputDispatch, KeyboardModifiers=window.WasmKeyboardModifierState;
    const WorldSteps=window.WasmWorldStepAccumulator, InputObjectTail=window.WasmInputObjectUpdateTail;
    const TargetHead=window.TargetHeadMesh, R6Parts=window.ArchivedR6Parts;
    const LinkedHead=window.LinkedR6HeadMesh, R6Face=window.ArchivedR6Face;
    const R6Animation=window.ArchivedR6Animation, R6AnimationData=window.ArchivedR6AnimationData;
    const StudTexture=window.RobloxStudTexture, CursorData=window.RobloxSwordCursors, ClassicCamera=window.RobloxClassicCameraAdapter;
    const RunningHeight=window.RunningHeightAdapter, SwordMesh=window.LinkedSwordMesh, SwordData=window.LinkedSwordData, R6Death=window.R6Death;
    const AirClips=window.ArchivedR6AirAnimationData, ActionClips=window.ArchivedR6ActionAnimationData;
    const SwordScript=window.LinkedSwordScript, SwordAudio=window.LinkedSwordAudio, SwordHit=window.LinkedSwordHit, DemoTarget=window.DemoTarget, Obstacles=window.DemoObstacles, Tools=window.ClassicToolsSim, TrowelData=window.ClassicTrowelData, RocketData=window.ClassicRocketData;
    if(!Block || !BlockFaceQuery || !PartView || !SpawnState || !AssetFS || !Chain || !Material || !DetachedUpdate || !MainQueue || !Keyboard || !KeyboardInput || !InputVector || !InputDispatch || !KeyboardModifiers || !WorldSteps || !InputObjectTail || !TargetHead || !R6Parts || !LinkedHead || !R6Face || !R6Animation || !R6AnimationData || !RunningHeight || !SwordMesh || !SwordData || !AirClips || !ActionClips || !SwordScript || !SwordAudio || !SwordHit || !DemoTarget || !Obstacles || !StudTexture || !CursorData || !ClassicCamera || !Tools || !TrowelData || !RocketData || !R6Death) throw new Error('A local research module did not load.');
    Object.assign(R6AnimationData.clips,AirClips,ActionClips,{carpetsit:window.RainbowCarpetSit,climb:window.R6ClimbData});
    const scenePath='/offline/baseplate.json';
    const authoredScene={baseplate:{size:[512,0.5,512],center:[0,-0.25,0],material:256}};
    const sceneBytes=new TextEncoder().encode(JSON.stringify(authoredScene));
    const assetFS=new AssetFS();
    if(assetFS.registerAsset(scenePath,sceneBytes.length)!==0 || assetFS.addFile(scenePath,sceneBytes)!==0)
    throw new Error('Could not stage the local demo scene.');
    const inline=assetFS.snapshot().inline[0];
    const scene=JSON.parse(new TextDecoder().decode(Uint8Array.from(inline.data)));
    const partBuffer=new ArrayBuffer(8192), partBytes=new DataView(partBuffer);
    const partAddress=64, primitiveAddress=512, geometryAddress=2048, customRecordAddress=4096;
    partBytes.setUint32(partAddress+260,primitiveAddress,true);
    partBytes.setUint32(primitiveAddress+396,geometryAddress,true);
    partBytes.setUint32(geometryAddress,8074444,true);
    partBytes.setUint8(primitiveAddress+338,56); // primitive constructor's initial flag byte
    partBytes.setUint8(primitiveAddress+339,2);  // primitive constructor's Block kind
    partBytes.setUint32(primitiveAddress+416,customRecordAddress,true); // demo's empty custom-property record
    partBytes.setUint16(primitiveAddress+430,scene.baseplate.material,true);
    const plate=new PartView(partBuffer,partAddress);
    const sizeHooks=Block.detachedSizeHooks(partBuffer,{
    call114418(p){
      const pointer=partBytes.getUint32(p+40,true), child=pointer?(pointer-8)>>>0:0;
      if(child)throw new Error('This demo cannot update a linked primitive.');
    },
    call114374(p){
      DetachedUpdate.apply(partBuffer,p,{
        lockHandle:0, mutex:value=>value,
        alloc(){throw new Error('This demo does not allocate connected node state.');},
        free(){throw new Error('This demo does not own connected node state.');}
      });
    }
    });
    plate.setPrimitiveSizeDetached(scene.baseplate.size,0,sizeHooks);
    const plateSize=plate.size;
    const runningHeight=RunningHeight.create(R6Parts.parts);
    const standingRootOffset=runningHeight.target(0,0);
    const demoPlateTop=scene.baseplate.center[1]+plateSize[1]/2;
    const runningFloorTarget=runningHeight.target(demoPlateTop,0);
    const shapeSize=[0,1,2].map(i=>partBytes.getFloat32(geometryAddress+4*i+4,true));
    const plateHalfBounds=Block.rotatedHalfExtents(shapeSize,[1,0,0,0,1,0,0,0,1]);
    const spawnProperties=new SpawnState();
    const defaults=spawnProperties.snapshot();

    const derivatives = !!gl.getExtension('OES_standard_derivatives');
    const {vertexSource,fragmentSource}=window.DemoShaders(derivatives);
    function compile(type, source) {
    const shader = gl.createShader(type); gl.shaderSource(shader, source); gl.compileShader(shader);
    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(shader) || 'Shader compilation failed');
    return shader;
    }
    const program = gl.createProgram();
    gl.attachShader(program, compile(gl.VERTEX_SHADER, vertexSource));
    gl.attachShader(program, compile(gl.FRAGMENT_SHADER, fragmentSource));
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(program) || 'Shader linking failed');
    gl.useProgram(program);
    const loc = {};
    for (const n of ['uViewProjection', 'uScale', 'uModel', 'uColor', 'uFloor', 'uCamera', 'uFace', 'uStud', 'uUseFace']) loc[n] = gl.getUniformLocation(program, n);
    const pos = gl.getAttribLocation(program, 'aPosition'), normal = gl.getAttribLocation(program, 'aNormal'), uv = gl.getAttribLocation(program, 'aUV');
    gl.enableVertexAttribArray(pos); gl.enableVertexAttribArray(normal);
    const vertices = [];
    function face(n, a, b, c, d) {
    for (const point of [a,b,c,a,c,d]) vertices.push(...point, ...n);
    }
    for(let side=0;side<Block.faceCount;side++){
    const corners=Block.faceVertices([1,1,1],side), n=Block.facePlane([1,1,1],side).slice(0,3);
    face(n,...corners);
    }
    const cube = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, cube); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);
    const targetHeadGeometry=TargetHead.geometry(),headGeometry=LinkedHead.geometry();
    const headBuffer=gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER,headBuffer); gl.bufferData(gl.ARRAY_BUFFER,headGeometry.vertices,gl.STATIC_DRAW);
    const headUVs=gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER,headUVs); gl.bufferData(gl.ARRAY_BUFFER,headGeometry.uvs,gl.STATIC_DRAW);
    const headIndices=gl.createBuffer(); gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,headIndices); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,headGeometry.indices,gl.STATIC_DRAW);
    const faceTexture=gl.createTexture();let faceLoaded=false;
    gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,faceTexture);
    gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,1,1,0,gl.RGBA,gl.UNSIGNED_BYTE,new Uint8Array([0,0,0,0]));
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
    const faceImage=new Image();faceImage.onload=()=>{gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,faceTexture);gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,false);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,faceImage);faceLoaded=true};
    faceImage.src=R6Face.dataUri;gl.uniform1i(loc.uFace,0);
    const studTexture=gl.createTexture();let studTextureLoaded=false;
    gl.activeTexture(gl.TEXTURE1);gl.bindTexture(gl.TEXTURE_2D,studTexture);
    gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,1,1,0,gl.RGBA,gl.UNSIGNED_BYTE,new Uint8Array([128,128,128,255]));
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.REPEAT);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.REPEAT);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
    const studImage=new Image();studImage.onload=()=>{gl.activeTexture(gl.TEXTURE1);gl.bindTexture(gl.TEXTURE_2D,studTexture);gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,false);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,studImage);gl.generateMipmap(gl.TEXTURE_2D);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR_MIPMAP_LINEAR);studTextureLoaded=true;gl.activeTexture(gl.TEXTURE0)};studImage.src=StudTexture.dataUri;gl.uniform1i(loc.uStud,1);gl.activeTexture(gl.TEXTURE0);
    const swordGeometry=SwordMesh.geometry(),swordBuffer=gl.createBuffer(),swordUVs=gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER,swordBuffer);gl.bufferData(gl.ARRAY_BUFFER,swordGeometry.vertices,gl.STATIC_DRAW);
    gl.bindBuffer(gl.ARRAY_BUFFER,swordUVs);gl.bufferData(gl.ARRAY_BUFFER,swordGeometry.uvs,gl.STATIC_DRAW);
    const swordTexture=gl.createTexture();gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,swordTexture);
    gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,1,1,0,gl.RGBA,gl.UNSIGNED_BYTE,new Uint8Array([255,255,255,255]));
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
    let swordTextureLoaded=false;const swordImage=new Image();swordImage.onload=()=>{gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,swordTexture);gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,false);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,swordImage);swordTextureLoaded=true};swordImage.src=SwordData.textureData;
    function loadClassicTool(data,uri){const geometry=data.geometry(),vertices=gl.createBuffer(),uvs=gl.createBuffer(),texture=gl.createTexture();gl.bindBuffer(gl.ARRAY_BUFFER,vertices);gl.bufferData(gl.ARRAY_BUFFER,geometry.vertices,gl.STATIC_DRAW);gl.bindBuffer(gl.ARRAY_BUFFER,uvs);gl.bufferData(gl.ARRAY_BUFFER,geometry.uvs,gl.STATIC_DRAW);gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,texture);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,1,1,0,gl.RGBA,gl.UNSIGNED_BYTE,new Uint8Array([255,255,255,255]));gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);const result={geometry,vertices,uvs,texture,loaded:false},img=new Image();img.onload=()=>{gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,texture);gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,false);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,img);result.loaded=true};img.src=uri;return result}
    const extraGeometry={trowel:loadClassicTool(TrowelData,TrowelData.textureData),rocket:loadClassicTool(RocketData,RocketData.textureData()),pistol:loadClassicTool(window.General45Data,window.General45Data.textureData())},carpetData=window.RainbowCarpetData,carpetTexture=carpetData.textureData();for(let i=0;i<5;i++)extraGeometry['carpet'+i]=loadClassicTool({geometry:()=>carpetData.geometry(i)},carpetTexture);
    const explosionRenderer=window.ExplosionRenderer1145.create(gl,window.RobloxExplosion1145),shieldRenderer=window.ForcefieldRenderer1145.create(gl,window.Forcefield1145Data);
    const diskData = [0,0,0, 0,1,0];
    for (let i=0; i<=40; i++) { const a=i*Math.PI*2/40; diskData.push(Math.cos(a),0,Math.sin(a), 0,1,0); }
    const disk = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, disk); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(diskData), gl.STATIC_DRAW);
    function buffer(which) {
    gl.bindBuffer(gl.ARRAY_BUFFER, which);
    gl.vertexAttribPointer(pos, 3, gl.FLOAT, false, 24, 0);
      gl.vertexAttribPointer(normal, 3, gl.FLOAT, false, 24, 12);
    }
    function draw(which, mode, count, scale, translation, yaw, color, floor, modelFrame) {
      buffer(which);gl.disableVertexAttribArray(uv);gl.vertexAttrib2f(uv,0,0);gl.uniform1f(loc.uUseFace,0);
      gl.uniform3fv(loc.uScale,scale);
      const frame=modelFrame||R6Animation.yawFrame(translation[0],translation[1],translation[2],yaw);
      gl.uniformMatrix4fv(loc.uModel,false,new Float32Array(frame));gl.uniform4fv(loc.uColor,color);gl.uniform1f(loc.uFloor,floor?1:0);
      gl.drawArrays(mode,0,count);
    }
    function box(scale,at,yaw,color,floor=false){draw(cube,gl.TRIANGLES,36,scale,at,yaw,color,floor)}
    function boxFrame(scale,modelFrame,color){draw(cube,gl.TRIANGLES,36,scale,null,0,color,false,modelFrame)}
    function linkedHeadFrame(scale,modelFrame,color) {
      buffer(headBuffer);gl.bindBuffer(gl.ARRAY_BUFFER,headUVs);gl.enableVertexAttribArray(uv);gl.vertexAttribPointer(uv,2,gl.FLOAT,false,8,0);
      gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,faceTexture);gl.uniform1f(loc.uUseFace,1);
      gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,headIndices);
      gl.uniform3fv(loc.uScale,scale);gl.uniformMatrix4fv(loc.uModel,false,new Float32Array(modelFrame));
      gl.uniform4fv(loc.uColor,color);gl.uniform1f(loc.uFloor,0);gl.drawElements(gl.TRIANGLES,headGeometry.indices.length,gl.UNSIGNED_SHORT,0);
    }
    function linkedSwordFrame(modelFrame){
      buffer(swordBuffer);gl.bindBuffer(gl.ARRAY_BUFFER,swordUVs);gl.enableVertexAttribArray(uv);gl.vertexAttribPointer(uv,2,gl.FLOAT,false,8,0);
      gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,swordTexture);gl.uniform1f(loc.uUseFace,1);
      gl.uniform3fv(loc.uScale,[1,1,1]);gl.uniformMatrix4fv(loc.uModel,false,new Float32Array(modelFrame));gl.uniform4fv(loc.uColor,[1,1,1,1]);gl.uniform1f(loc.uFloor,0);
      gl.drawArrays(gl.TRIANGLES,0,swordGeometry.vertexCount);
    }
    function classicToolFrame(type,modelFrame){const tool=extraGeometry[type];buffer(tool.vertices);gl.bindBuffer(gl.ARRAY_BUFFER,tool.uvs);gl.enableVertexAttribArray(uv);gl.vertexAttribPointer(uv,2,gl.FLOAT,false,8,0);gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,tool.texture);gl.uniform1f(loc.uUseFace,1);gl.uniform3fv(loc.uScale,[1,1,1]);gl.uniformMatrix4fv(loc.uModel,false,new Float32Array(modelFrame));gl.uniform4fv(loc.uColor,[1,1,1,1]);gl.uniform1f(loc.uFloor,0);gl.drawArrays(gl.TRIANGLES,0,tool.geometry.vertexCount)}
    function perspective(fovy, aspect, near, far) {
      const f=1/Math.tan(fovy/2), out=new Float32Array(16);
      out[0]=f/aspect; out[5]=f; out[10]=(far+near)/(near-far); out[11]=-1; out[14]=2*far*near/(near-far); return out;
    }
    function lookAt(eye, center) {
      let zx=eye[0]-center[0], zy=eye[1]-center[1], zz=eye[2]-center[2];
      let l=Math.hypot(zx,zy,zz)||1; zx/=l; zy/=l; zz/=l;
      let xx=zz, xy=0, xz=-zx; l=Math.hypot(xx,xy,xz)||1; xx/=l; xy/=l; xz/=l;
      const yx=zy*xz-zz*xy, yy=zz*xx-zx*xz, yz=zx*xy-zy*xx;
      return new Float32Array([xx,yx,zx,0, xy,yy,zy,0, xz,yz,zz,0,
        -(xx*eye[0]+xy*eye[1]+xz*eye[2]), -(yx*eye[0]+yy*eye[1]+yz*eye[2]), -(zx*eye[0]+zy*eye[1]+zz*eye[2]), 1]);
    }
    function multiply(a,b) {
      const o=new Float32Array(16);
      for(let col=0;col<4;col++) for(let row=0;row<4;row++)
        o[col*4+row]=a[row]*b[col*4]+a[4+row]*b[col*4+1]+a[8+row]*b[col*4+2]+a[12+row]*b[col*4+3];
      return o;
    }
    const inputMemory=new ArrayBuffer(MainQueue.layout.READ+4), eventQueue=new MainQueue(inputMemory);
    const keyboardInput=new KeyboardInput(eventQueue), inputContext=1024, inputObject=8192, inputScratch=4096;
    const inputVector=inputObject+136, inputStorage=16384, inputCapacity=MainQueue.layout.usable;
    eventQueue.view.setInt32(inputVector,inputStorage,true);
    eventQueue.view.setInt32(inputVector+4,inputStorage,true);
    eventQueue.view.setInt32(inputVector+8,inputStorage+12*inputCapacity,true);
    const inputHooks={lock(){},unlock(){},resolve(context,name){
      if(context!==inputContext||name!==InputDispatch.NAME)throw new Error('Unexpected demo input context');
      return inputObject;
    },alloc(){throw new Error('The demo input vector capacity was exceeded');},free(){throw new Error('The demo input vector does not own dynamic memory');}};
    const inputTelemetry={forwarded:0,filtered:0,objectUpdates:0,objectDispatches:0};
    const demoInputObjects=new Map(); let nextDemoInputObject=32768;
    const objectHooks={setState(v,p,x){v.setInt32(p+20,x,true);},setLogical(v,p,x){v.setInt32(p+16,x,true);},notify(){},signal(){}};
    function demoObjectFor(physical){
      if(!demoInputObjects.has(physical)){
        if(nextDemoInputObject+256>4_000_000)throw new Error('Demo input object capacity exceeded');
        const address=nextDemoInputObject; nextDemoInputObject+=256;
        eventQueue.bytes.fill(0,address,address+256);
        eventQueue.view.setInt32(address+112,2,true); // demo initial released state
        demoInputObjects.set(physical,address);
      }
      return demoInputObjects.get(physical);
    }
    function clearDemoInputObjects(){demoInputObjects.clear();nextDemoInputObject=32768;}
    const demoKeys=new Map([[119,'KeyW'],[97,'KeyA'],[115,'KeyS'],[100,'KeyD'],
      [273,'ArrowUp'],[276,'ArrowLeft'],[274,'ArrowDown'],[275,'ArrowRight'],[32,'Space']]);
    const held=new Set(),cameraKeys=new Set();
    const motionDefaults=Object.freeze({walkSpeed:16,jumpPower:50,gravity:196.2,airGlideGravityScale:.8});
    const player={x:0,y:0,z:0,vy:0,grounded:true,gliding:false,yaw:0,walk:0,moving:false,seated:false,seatCooldown:0,seatLock:false,jumpTime:0,climbing:false,climbExit:false,climbSpeed:0,climbCooldown:0,climbVX:0,climbVZ:0};
    const r6Animator=R6Animation.create(R6AnimationData),sword=SwordScript.create(),demoTarget=DemoTarget.create(),demoTools=Tools.create(),carpet=window.RainbowCarpet.create();let r6Matrices=r6Animator.step(0,0),attackSerial=0,localHealth=100,lastHazardTime=-Infinity;
    let swordSoundAttempts=0,lastSwordSound=null,lastSwordVolume=null,queuedSword=false,activeSwordDamage=5,activeSwordAt=-Infinity;const activeSwordSounds=new Set();
    window.addEventListener('hud:volume-changed',e=>{for(const sound of activeSwordSounds)sound.audio.volume=clamp(sound.base*e.detail.volume,0,1)});
    function playSwordSound(name){
      const source=SwordAudio[name];if(!source)return;lastSwordSound=name;swordSoundAttempts++;
      try{const audio=new Audio(source.dataUri),master=window.__localAudio?window.__localAudio.volume:.5,playing={audio,base:source.volume};audio.volume=clamp(source.volume*master,0,1);lastSwordVolume=audio.volume;activeSwordSounds.add(playing);audio.addEventListener('ended',()=>activeSwordSounds.delete(playing),{once:true});const play=audio.play();if(play&&play.catch)play.catch(()=>activeSwordSounds.delete(playing));}catch(e){}
    }
    function activateSword(){
      if(window.__hudInteraction&&window.__hudInteraction.blocksGameplay(canvas))return;
      const t=performance.now()/1000,action=sword.activate(t);if(!action.accepted){if(sword.getState().equipped&&!sword.getState().enabled)queuedSword=true;return}queuedSword=false;activeSwordDamage=action.damage;activeSwordAt=t;attackSerial++;
      r6Animator.triggerToolAction(action.toolanim);playSwordSound(action.sound);
    }
    let cursorKind='default';
    function updateToolCursor(state){const tool=window.__robloxBackpack&&window.__robloxBackpack.getState().equippedTool,enabled=tool==='sword'?state.enabled:tool==='carpet'?true:tool==='pistol'?!gun.getState().reloading:performance.now()/1000>=demoTools.readyAt(tool),kind=!tool?'default':enabled?'ready':'wait';if(kind===cursorKind)return;cursorKind=kind;canvas.style.cursor=kind==='default'?'':`url("${kind==='ready'?CursorData.ready:CursorData.wait}") 40 40, crosshair`;}
    window.addEventListener('backpack:changed',e=>{if(!e.detail.equipped||e.detail.equippedTool!=='sword')queuedSword=false;if(e.detail.equippedTool!=='carpet')carpet.stop(player);const sound=sword.equip(!!e.detail.equipped&&e.detail.equippedTool==='sword');updateToolCursor(sword.getState());if(sound)playSwordSound(sound)});
    function playToolAudio(uri){try{const audio=new Audio(uri);audio.volume=clamp(window.__localAudio?window.__localAudio.volume:.5,0,1);const promise=audio.play();if(promise&&promise.catch)promise.catch(()=>{})}catch(e){}}
    function activateEquipped(x,y){if(playerDeath)return;const tool=window.__robloxBackpack&&window.__robloxBackpack.getState().equippedTool;if(tool==='sword'){activateSword();return}if(tool==='carpet'){carpet.toggle(player);return}if(tool==='pistol'){gun.fire(x,y);return}if(!tool)return;const t=performance.now()/1000,target=tool==='rocket'?Tools.aimTarget(x,y,canvas.getBoundingClientRect(),cameraEye,camera,demoTarget.getState(),Obstacles,demoTools.getState(t).walls):null,root=R6Animation.yawFrame(player.x,player.y+standingRootOffset,player.z,player.yaw+Math.PI),origin=tool==='rocket'?Tools.rocketMuzzle(player,target,DemoTarget.point(classicModelFrame(root,'rocket'),[5,0,0])):null;if(demoTools.activate(tool,target,player,t,{origin}))playToolAudio(tool==='rocket'?RocketData.whooshData():TrowelData.buildSound)}
    const rightCameraLock=window.RightCameraLock.create(canvas);
    const shiftIcon=document.getElementById('rbx-shift-cursor');shiftIcon.src=window.CharacterEffects.shiftIcon;
    const characterSoundCounts={jump:0,death:0};let lastDummyHealth=100,playerDeath=null,forcefieldUntil=performance.now()/1000+10,carpetCollected=false;
    function playCharacterSound(kind){const source=window.R6LocalAudio&&window.R6LocalAudio[kind];if(!source)return;characterSoundCounts[kind]++;try{const audio=new Audio(source.dataUri);audio.volume=clamp(window.__localAudio?window.__localAudio.volume:.5,0,1);const played=audio.play();if(played&&played.catch)played.catch(()=>{})}catch(e){}}
    const camera={yaw:0.45,pitch:0.43,distance:ClassicCamera.source.defaultDistance};let cameraFocus=[0,0,0],cameraEye=[0,0,0],clickTarget=null,lastCameraPan=0;
    const gun=window.General45.create(()=>({player,canvas,eye:cameraEye,camera,target:demoTarget,obstacles:Obstacles,tools:demoTools,mp:window.__multiplayer,muzzle:()=>DemoTarget.point(classicModelFrame(R6Animation.yawFrame(player.x,player.y+standingRootOffset,player.z,player.yaw+Math.PI),'pistol'),[0,0,-1.2])}));
    let jumpQueued=false, lastFrame=0, dragging=false, pointerId=null, lastX=0, lastY=0,downX=0,downY=0,downButton=-1,pointerMoved=false;
    const clamp=(v,min,max)=>Math.max(min,Math.min(max,v));
    function respawnPlayer() {
      playerDeath=null;forcefieldUntil=performance.now()/1000+10;queuedSword=false;carpet.stop(player);
      Object.assign(player,{x:0,y:0,z:0,vy:0,grounded:true,gliding:false,yaw:0,walk:0,moving:false,seated:false,seatCooldown:0,seatLock:false,jumpTime:0,climbing:false,climbExit:false,climbSpeed:0,climbCooldown:0,climbVX:0,climbVZ:0});
      r6Animator.reset();sword.reset();gun.reset();attackSerial=0;localHealth=100;lastHazardTime=-Infinity;r6Matrices=r6Animator.step(0,0);
      if(window.__robloxBackpack)window.__robloxBackpack.unequip();
      Object.assign(camera,{yaw:0.45,pitch:0.43,distance:ClassicCamera.source.defaultDistance});clickTarget=null;if(document.pointerLockElement===canvas)document.exitPointerLock();if(window.__localSettings)window.__localSettings.setShiftLocked(false);held.clear();cameraKeys.clear();jumpQueued=false;clearDemoInputObjects();
      if(window.__robloxHudResearch)window.__robloxHudResearch.setHealth(100,100,false,true);
    }
    function reset(){respawnPlayer();demoTarget.reset();demoTools.reset();lastDummyHealth=100}
    function diePlayer(impulse=null,blastCenter=null){
      if(playerDeath)return;
      const root=carpet.active?carpet.rootFrame(R6Animation,player,standingRootOffset):R6Animation.yawFrame(player.x,player.y+standingRootOffset,player.z,player.yaw+Math.PI);
      const snapshots=R6Death.names.map(name=>{const m=R6Animation.multiply(root,r6Matrices[name]);return{name,size:R6Parts.parts[name].size.slice(),center:m.slice(12,15),rotation:R6Animation.quat(m)}});
      const validBlast=Array.isArray(blastCenter)&&blastCenter.length===3&&blastCenter.every(Number.isFinite),speed=player.moving?motionDefaults.walkSpeed:0,velocity=[Math.sin(player.yaw)*speed+(validBlast?0:impulse?.[0]||0),player.vy+(validBlast?0:impulse?.[1]||0),Math.cos(player.yaw)*speed+(validBlast?0:impulse?.[2]||0)],now=performance.now()/1000;
      playerDeath={sim:R6Death.create(snapshots,velocity),startedAt:now,respawnAt:now+R6Death.RESPAWN_SECONDS};if(validBlast)playerDeath.sim.blast(blastCenter,Tools.demoOverride.rocketImpulse,8);
      localHealth=0;forcefieldUntil=0;queuedSword=false;carpet.stop(player);player.moving=false;player.seated=false;player.gliding=false;held.clear();jumpQueued=false;clickTarget=null;
      if(window.__robloxBackpack)window.__robloxBackpack.unequip();sword.reset();
      if(window.__robloxHudResearch)window.__robloxHudResearch.setHealth(0,100,true,true);
      playCharacterSound('death');
    }
    function takeLocalDamage(amount,direct=false,impulse=null,blastCenter=null){if(playerDeath||!Number.isFinite(amount)||amount<=0||(!direct&&performance.now()/1000<forcefieldUntil))return false;localHealth=Math.max(0,localHealth-amount);if(localHealth===0){diePlayer(impulse,blastCenter);return true}if(window.__robloxHudResearch)window.__robloxHudResearch.setHealth(localHealth,100,false,true);return true}
    function deathSurface(x,z,oldBottom,ext){
      let floor=Math.abs(x)<plateHalfBounds[0]&&Math.abs(z)<plateHalfBounds[2]?demoPlateTop:null;
      for(const part of Obstacles.collisionParts){const top=part.center[1]+part.size[1]/2;if(oldBottom>=top-.2&&Math.abs(x-part.center[0])<=part.size[0]/2+Math.min(ext[0],.5)&&Math.abs(z-part.center[2])<=part.size[2]/2+Math.min(ext[2],.5))floor=floor===null?top:Math.max(floor,top)}
      return floor;
    }
    const controlled=new Set(['KeyW','KeyA','KeyS','KeyD','ArrowUp','ArrowLeft','ArrowDown','ArrowRight','Space']);
    window.addEventListener('keydown', e => {
      if (window.__hudInteraction && window.__hudInteraction.blocksGameplay(e.target)) return;
      if (e.target && e.target.closest && e.target.closest('button') && e.code==='Space') return;
      if(e.code==='ArrowLeft'||e.code==='ArrowRight'){e.preventDefault();cameraKeys.add(e.code);lastCameraPan=performance.now();return}
      if (controlled.has(e.code)) {e.preventDefault();if(e.code!=='Space')clickTarget=null;}
      if(!e.repeat&&(e.code==='ShiftLeft'||e.code==='ShiftRight')&&window.__localSettings){const x=window.__localSettings.getState();if(x.shiftLock){if(document.pointerLockElement===canvas)document.exitPointerLock();else if(canvas.requestPointerLock){const request=canvas.requestPointerLock();if(request&&request.catch)request.catch(()=>window.__localSettings.setShiftLocked(false))}e.preventDefault();return}}
      if(!e.repeat&&(e.code==='KeyI'||e.code==='KeyO')){camera.distance=ClassicCamera.zoom(camera.distance,e.code==='KeyI'?-.5:.5);e.preventDefault()}
      keyboardInput.handle(2,e);
    });
    window.addEventListener('keyup', e => {if(e.code==='ArrowLeft'||e.code==='ArrowRight'){cameraKeys.delete(e.code);e.preventDefault();return}if(window.__hudInteraction && window.__hudInteraction.blocksGameplay(e.target)) return; keyboardInput.handle(3,e); });
    document.addEventListener('pointerlockchange',()=>{const locked=document.pointerLockElement===canvas&&!rightCameraLock.isRightLook();shiftIcon.hidden=!locked;if(window.__localSettings)window.__localSettings.setShiftLocked(locked)});
    document.addEventListener('pointerlockerror',()=>{shiftIcon.hidden=true;if(window.__localSettings)window.__localSettings.setShiftLocked(false)});
    window.addEventListener('hud:local-settings',e=>{if(!e.detail.shiftLock&&document.pointerLockElement===canvas&&!rightCameraLock.isRightLook())document.exitPointerLock()});
    window.addEventListener('hud:control-suspend',()=>{if(document.pointerLockElement===canvas)document.exitPointerLock();eventQueue.drain(()=>{});eventQueue.view.setInt32(inputVector+4,inputStorage,true);held.clear();cameraKeys.clear();jumpQueued=false;clearDemoInputObjects();eventQueue.view.setInt32(inputObject+176,0,true);dragging=false;clickTarget=null;});
    window.addEventListener('blur', () => { eventQueue.drain(()=>{}); held.clear(); cameraKeys.clear(); clearDemoInputObjects(); eventQueue.view.setInt32(inputObject+176,0,true); dragging=false; }); // demo focus cleanup
    function dispatchKeyboardRecord(address,record) {
      if(record[0]!==0)return;
      const physical=eventQueue.view.getInt32(address+8,true);
      const kept=InputDispatch.dispatch(inputMemory,inputContext,inputScratch,record[4],physical,
        Keyboard.logicalFromCode(physical),record[12],inputHooks);
      if(kept)inputTelemetry.forwarded++;else inputTelemetry.filtered++;
    }
    function consumeDemoInput() {
      const view=eventQueue.view,end=view.getInt32(inputVector+4,true);
      for(let at=inputStorage;at<end;at+=12){
        KeyboardModifiers.apply(inputMemory,inputObject,at); // 3107 modifier-mask switch
        const down=view.getUint8(at)!==0,repeat=view.getUint8(at+1)!==0;
        const physical=view.getInt32(at+8,true),logical=view.getInt32(at+4,true);
        const gate=InputObjectTail.update(inputMemory,demoObjectFor(physical),down,repeat,physical,logical,view.getInt32(inputObject+176,true),objectHooks);
        inputTelemetry.objectUpdates++; if(gate)inputTelemetry.objectDispatches++;
        const key=demoKeys.get(logical);
        if(!key||!gate)continue; // demo adapter; 92288 itself is not recovered
        if(down){if(key==='Space'&&!repeat)jumpQueued=true;held.add(key);}else held.delete(key);
      }
      view.setInt32(inputVector+4,inputStorage,true);
    }
    let touchCamera=null;const touchMove=window.MobileInput.create(document.getElementById('rbx-touch-stick'),()=>{clickTarget=null}),clearTouchMove=()=>touchMove.clear();
    canvas.addEventListener('pointerdown', e => {
      if(e.pointerType==='touch'){if(!touchCamera){touchCamera={id:e.pointerId,x:e.clientX,y:e.clientY,startX:e.clientX,startY:e.clientY,moved:false};canvas.setPointerCapture(e.pointerId)}e.preventDefault();return}
      if(e.button!==0&&e.button!==2)return;
      canvas.focus({preventScroll:true});e.preventDefault();
      if(e.button===0){const opt=window.__localSettings&&window.__localSettings.getState();if(opt&&opt.movementMode==='Click to Move'&&!(window.__robloxBackpack&&window.__robloxBackpack.getState().equipped))clickTarget=groundTarget(e.clientX,e.clientY);else{activateEquipped(e.clientX,e.clientY);updateToolCursor(sword.getState())}return}
      if(document.pointerLockElement===canvas&&!rightCameraLock.isRightLook())return;dragging=true;pointerId=e.pointerId;lastX=e.clientX;lastY=e.clientY;if(!rightCameraLock.isRightLook()&&document.pointerLockElement!==canvas)canvas.setPointerCapture(e.pointerId);
    });
    canvas.addEventListener('pointermove', e => {
      const sensitivity=window.__hudInteraction?window.__hudInteraction.sensitivity:1;
      if(touchCamera&&e.pointerId===touchCamera.id){const dx=e.clientX-touchCamera.x,dy=e.clientY-touchCamera.y;if(Math.hypot(e.clientX-touchCamera.startX,e.clientY-touchCamera.startY)>7)touchCamera.moved=true;if(touchCamera.moved){lastCameraPan=performance.now();camera.yaw-=dx*.0065*sensitivity;camera.pitch=clamp(camera.pitch+dy*.005*sensitivity,-ClassicCamera.source.pitchLimit,ClassicCamera.source.pitchLimit)}touchCamera.x=e.clientX;touchCamera.y=e.clientY;e.preventDefault();return}
      if(document.pointerLockElement===canvas){lastCameraPan=performance.now();camera.yaw-=e.movementX*.0065*sensitivity;camera.pitch=clamp(camera.pitch+e.movementY*.005*sensitivity,-ClassicCamera.source.pitchLimit,ClassicCamera.source.pitchLimit);return}
      if(!dragging||e.pointerId!==pointerId)return;
      lastCameraPan=performance.now();camera.yaw-=(e.clientX-lastX)*0.0065*sensitivity;
      camera.pitch=clamp(camera.pitch+(e.clientY-lastY)*0.005*sensitivity,-ClassicCamera.source.pitchLimit,ClassicCamera.source.pitchLimit);
      lastX=e.clientX;lastY=e.clientY;
    });
    function groundTarget(clientX,clientY){const r=canvas.getBoundingClientRect(),nx=(clientX-r.left)/r.width*2-1,ny=1-(clientY-r.top)/r.height*2,cp=Math.cos(camera.pitch),sp=Math.sin(camera.pitch),sy=Math.sin(camera.yaw),cy=Math.cos(camera.yaw),k=Math.tan(Math.PI/6),aspect=r.width/r.height;
      const forward=[-sy*cp,-sp,-cy*cp],right=[cy,0,-sy],up=[-sy*sp,cp,-cy*sp],dir=forward.map((v,i)=>v+right[i]*nx*k*aspect+up[i]*ny*k);if(dir[1]>=-.0001)return null;const t=-cameraEye[1]/dir[1];if(t<=0)return null;return{x:clamp(cameraEye[0]+dir[0]*t,-plateHalfBounds[0],plateHalfBounds[0]),z:clamp(cameraEye[2]+dir[2]*t,-plateHalfBounds[2],plateHalfBounds[2])}}
    function endPointer(e){if(touchCamera&&e.pointerId===touchCamera.id){if(e.type==='pointerup'&&!touchCamera.moved){const opt=window.__localSettings&&window.__localSettings.getState();if(opt&&opt.movementMode==='Click to Move'&&!(window.__robloxBackpack&&window.__robloxBackpack.getState().equipped))clickTarget=groundTarget(e.clientX,e.clientY);else activateEquipped(e.clientX,e.clientY)}touchCamera=null;return}if(e.pointerId===pointerId){dragging=false;pointerId=null}}
    canvas.addEventListener('pointerup',endPointer);canvas.addEventListener('pointercancel',endPointer);canvas.addEventListener('lostpointercapture',endPointer);
    canvas.addEventListener('contextmenu',e=>e.preventDefault());
    canvas.addEventListener('wheel',e=>{e.preventDefault();const pixels=e.deltaY*(e.deltaMode===1?16:e.deltaMode===2?canvas.clientHeight:1);camera.distance=ClassicCamera.zoom(camera.distance,clamp(pixels/300,-4,4));},{passive:false});
    for (const button of document.querySelectorAll('[data-touch]')) {
      const key=button.dataset.touch;
      button.addEventListener('pointerdown',e=>{ e.preventDefault(); if(window.__hudInteraction&&window.__hudInteraction.blocksGameplay(e.target))return; button.setPointerCapture(e.pointerId); if(key==='Space') jumpQueued=true; else held.add(key); });
      const release=()=>held.delete(key);
      button.addEventListener('pointerup',release); button.addEventListener('pointercancel',release); button.addEventListener('lostpointercapture',release);
    }
    window.addEventListener('hud:control-suspend',()=>{clearTouchMove();touchCamera=null});window.addEventListener('blur',clearTouchMove);
    window.__touchController=Object.freeze({getState:()=>({side:touchMove.side,forward:touchMove.forward,cameraDragging:!!touchCamera})});
    let faceQueryChecks=0;
    function update(dt,swordFrame) {
      const cameraTurn=(cameraKeys.has('ArrowLeft')?1:0)-(cameraKeys.has('ArrowRight')?1:0);if(cameraTurn){camera.yaw+=cameraTurn*1.8*dt;lastCameraPan=performance.now()}
      if(playerDeath){jumpQueued=false;return}
      if(!carpetCollected&&Math.abs(player.y-Obstacles.platform.top)<1.5&&Math.hypot(player.x-Obstacles.carpetPickup.center[0],player.z-Obstacles.carpetPickup.center[2])<Obstacles.carpetPickup.radius){carpetCollected=window.__robloxBackpack.grantTool('carpet')}
      player.seatCooldown=Math.max(0,player.seatCooldown-dt);
      player.jumpTime=Math.max(0,player.jumpTime-dt);
      if(player.seated){
        player.moving=false;player.gliding=false;
        if(jumpQueued){playCharacterSound('jump');player.seated=false;player.seatLock=true;player.seatCooldown=1;player.y=Obstacles.chair.seatTop;player.vy=motionDefaults.jumpPower;player.grounded=false;player.jumpTime=.3;}
        else {jumpQueued=false;return;}
      }
      if(carpet.active){const flightHeld=new Set(held);if(touchMove.forward>.1)flightHeld.add('KeyW');if(touchMove.forward<-.1)flightHeld.add('KeyS');if(touchMove.side>.1)flightHeld.add('KeyD');if(touchMove.side<-.1)flightHeld.add('KeyA');carpet.step(dt,player,camera,flightHeld,performance.now()/1000);jumpQueued=false;return}
      const forward=clamp((held.has('KeyW')||held.has('ArrowUp')?1:0)-(held.has('KeyS')||held.has('ArrowDown')?1:0)+touchMove.forward,-1,1),side=clamp((held.has('KeyD')?1:0)-(held.has('KeyA')?1:0)+touchMove.side,-1,1);
      player.climbCooldown=Math.max(0,player.climbCooldown-dt);if(jumpQueued&&window.HumanoidClimbing.jump(player,Obstacles.climbables,motionDefaults.jumpPower)){jumpQueued=false;playCharacterSound('jump')}
      if(window.HumanoidClimbing.step(player,{forward,side,cameraYaw:camera.yaw,walkSpeed:motionDefaults.walkSpeed},dt,Obstacles.climbables)){jumpQueued=false;return}
      let dx=-Math.sin(camera.yaw)*forward+Math.cos(camera.yaw)*side;
      let dz=-Math.cos(camera.yaw)*forward-Math.sin(camera.yaw)*side;let goalDistance=Infinity;if(!player.grounded&&player.climbCooldown>0){dx+=player.climbVX/motionDefaults.walkSpeed;dz+=player.climbVZ/motionDefaults.walkSpeed;player.climbVX*=Math.exp(-2*dt);player.climbVZ*=Math.exp(-2*dt)}
      if(!forward&&!side&&clickTarget){dx=clickTarget.x-player.x;dz=clickTarget.z-player.z;goalDistance=Math.hypot(dx,dz);if(goalDistance<.2){clickTarget=null;dx=dz=0}}
      const length=Math.hypot(dx,dz);
      player.moving=length>0;
      if(length>0){
        dx/=length;dz/=length;const step=Math.min(motionDefaults.walkSpeed*dt*(clickTarget?1:Math.min(1,length)),goalDistance),x=player.x+dx*step,z=player.z+dz*step;
        const pass=(px,pz)=>!Obstacles.blocked(px,pz,player.y,player.grounded,player.x,player.z)&&!demoTarget.blocksPlayer(px,pz,player.y,player.x,player.z)&&!demoTools.blocksPlayer(px,pz,player.y,player.x,player.z,performance.now()/1000);
        if(pass(x,z)){player.x=x;player.z=z}else if(pass(x,player.z)){player.x=x}else if(pass(player.x,z)){player.z=z}else{player.moving=false;clickTarget=null}
        const settings=window.__localSettings&&window.__localSettings.getState(),targetHeading=settings&&settings.shiftLocked?camera.yaw-Math.PI:Math.atan2(dx,dz),headingDelta=Math.atan2(Math.sin(targetHeading-player.yaw),Math.cos(targetHeading-player.yaw));player.yaw+=headingDelta*(1-Math.exp(-12*dt));if(player.moving)player.walk+=dt*9;
        if(settings&&settings.cameraMode.includes('Follow')&&!settings.shiftLocked&&performance.now()-lastCameraPan>2000){const targetYaw=player.yaw+Math.PI,diff=Math.atan2(Math.sin(targetYaw-camera.yaw),Math.cos(targetYaw-camera.yaw));camera.yaw+=diff*(1-Math.exp(-2*dt))}
      }
      if(window.__localSettings&&window.__localSettings.getState().shiftLocked)player.yaw=camera.yaw-Math.PI;
      faceQueryChecks++;
      const overPlate=plate.canCollide&&BlockFaceQuery.projectionInside(plateSize,1,[player.x-scene.baseplate.center[0],player.y-scene.baseplate.center[1],player.z-scene.baseplate.center[2]]);
      const stairHeight=Obstacles.stairTop(player.x,player.z,player.y);
      const staticGround=overPlate?Math.max(runningFloorTarget-standingRootOffset,stairHeight??-Infinity):stairHeight,brickTop=demoTools.supportTop(player.x,player.z,player.y,performance.now()/1000),ground=brickTop===null?staticGround:staticGround===null?brickTop:Math.max(staticGround,brickTop);
      const stepDelta=ground===null?Infinity:ground-player.y,stepping=player.grounded&&Math.abs(stepDelta)>.0001&&Math.abs(stepDelta)<=.751;
      if(stepping)player.y+=Math.sign(stepDelta)*Math.min(Math.abs(stepDelta),10*dt);
      if(jumpQueued&&player.grounded){playCharacterSound('jump');player.vy=motionDefaults.jumpPower;player.grounded=false;player.jumpTime=.3;}
      jumpQueued=false;
      player.gliding=!!(swordFrame.forceUp&&!player.grounded&&player.vy<0);
      const gravityScale=player.gliding?motionDefaults.airGlideGravityScale:1;
      if(stepping&&player.grounded){player.vy=0;player.gliding=false}
      else{const oldY=player.y;player.vy-=motionDefaults.gravity*gravityScale*dt;player.y+=player.vy*dt;const ceiling=Obstacles.ceiling(player.x,player.z,oldY,player.y);if(ceiling!==null&&player.vy>0){player.y=ceiling;player.vy=0}
        if(ground!==null&&player.vy<=0&&player.y<=ground){player.y=ground;player.vy=0;player.grounded=true;player.gliding=false;}else player.grounded=false;}
      if(player.seatLock&&(Math.abs(player.x-Obstacles.chair.center[0])>1.7||Math.abs(player.z-Obstacles.chair.center[1])>1.7))player.seatLock=false;
      if(!player.seatLock&&!swordFrame.forceUp&&Obstacles.seatCandidate(player.x,player.z,player.y,player.grounded,player.seatCooldown)){
        player.seated=true;player.x=Obstacles.chair.center[0];player.z=Obstacles.chair.center[1];player.y=Obstacles.chair.seatTop-2;player.yaw=Obstacles.chair.yaw;player.vy=0;player.grounded=true;player.moving=false;player.jumpTime=0;
      }
      const hazard=demoTools.hazardAt(player),now=performance.now()/1000;if(hazard&&now-lastHazardTime>=1){lastHazardTime=now;takeLocalDamage(hazard.kind==='kill'?100:10,hazard.kind==='kill')}
      if(player.y < -40)diePlayer();
    }
    function resize() {
      const settings=window.__localSettings&&window.__localSettings.getState(),quality=settings&&settings.graphicsMode==='Manual'?.5+settings.graphicsQuality*.05:1;const dpr=Math.min(window.devicePixelRatio||1,2)*quality;
      const w=Math.max(1,Math.round(canvas.clientWidth*dpr)), h=Math.max(1,Math.round(canvas.clientHeight*dpr));
      if(canvas.width!==w || canvas.height!==h){ canvas.width=w; canvas.height=h; }
      gl.viewport(0,0,w,h);
    }
    function swordModelFrame(rootFrame){
      if(!sword.getState().equipped)return null;
      const arm=R6Animation.multiply(rootFrame,r6Matrices['Right Arm']);
      const attachment=R6Animation.fromCFrame(SwordData.rightGripAttachment);
      const r6WeldRotation=R6Animation.fromCFrame({position:[0,0,0],rotation:[1,0,0,0,0,1,0,-1,0]});
      const hand=R6Animation.multiply(attachment,r6WeldRotation),grip=R6Animation.inverseRigid(R6Animation.fromCFrame(SwordScript.grips[sword.getState().grip]));
      return R6Animation.multiply(R6Animation.multiply(arm,hand),grip);
    }
    function classicModelFrame(rootFrame,type){const arm=R6Animation.multiply(rootFrame,r6Matrices['Right Arm']),attachment=R6Animation.fromCFrame(SwordData.rightGripAttachment),weld=R6Animation.fromCFrame({position:[0,0,0],rotation:[1,0,0,0,0,1,0,-1,0]}),grip=R6Animation.inverseRigid(R6Animation.fromCFrame(type==='trowel'?TrowelData.grip:type==='carpet'?carpetData.grip:type==='pistol'?window.General45Data.grip:RocketData.grip));return R6Animation.multiply(R6Animation.multiply(arm,R6Animation.multiply(attachment,weld)),grip)}
    function render() {
      resize();
      const rootFrame=carpet.active?carpet.rootFrame(R6Animation,player,standingRootOffset):R6Animation.yawFrame(player.x,player.y+standingRootOffset,player.z,player.yaw+Math.PI),weaponFrame=playerDeath?null:swordModelFrame(rootFrame);
      const time=performance.now()/1000,ss=sword.getState();demoTarget.step(time,weaponFrame,{...ss,damage:ss.action==='Lunge'||time-activeSwordAt<.35?activeSwordDamage:ss.damage,attackSerial},player);const outcome=demoTools.step(time,player,demoTarget,Obstacles,{frame:weaponFrame,serial:attackSerial,active:ss.equipped&&(ss.action==='Lunge'||time-ss.lastAttack<.35)});if(outcome.playerDamage)takeLocalDamage(outcome.playerDamage,false,outcome.playerImpulse,outcome.exploded[0]?.center);if(outcome.exploded.length)playToolAudio(RocketData.boomData);const dummy=demoTarget.getState(),toolState=demoTools.getState(time);if(lastDummyHealth>0&&dummy.health<=0)playCharacterSound('death');lastDummyHealth=dummy.health;
      gl.clearColor(0,0,0,0); gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT); gl.enable(gl.DEPTH_TEST); gl.depthFunc(gl.LEQUAL);
      const head=playerDeath&&playerDeath.sim.getParts().find(p=>p.name==='Head'),cp=Math.cos(camera.pitch),target=head?[head.center[0],head.center[1]-.35,head.center[2]]:ClassicCamera.focus(player,standingRootOffset),settings=window.__localSettings&&window.__localSettings.getState();if(settings&&settings.shiftLocked&&camera.distance>=1){target[0]+=Math.cos(camera.yaw)*1.75;target[2]-=Math.sin(camera.yaw)*1.75}
      const eye=[target[0]+Math.sin(camera.yaw)*cp*camera.distance,target[1]+Math.sin(camera.pitch)*camera.distance,target[2]+Math.cos(camera.yaw)*cp*camera.distance];cameraFocus=target;cameraEye=eye;
      const vp=multiply(perspective(Math.PI/3,canvas.width/canvas.height,0.1,800),lookAt(eye,target));
      gl.uniformMatrix4fv(loc.uViewProjection,false,vp);
      gl.uniform3fv(loc.uCamera,eye);
      const bp=[player.x,player.y+standingRootOffset+2.15,player.z,1],bc=[0,1,2,3].map(r=>bp.reduce((sum,v,c)=>sum+vp[c*4+r]*v,0)),bx=bc[0]/bc[3],by=bc[1]/bc[3],bubbleVisible=chatBubble.dataset.active==='true'&&bc[3]>0&&Math.abs(bx)<1.1&&Math.abs(by)<1.1;chatBubble.hidden=!bubbleVisible;if(bubbleVisible){chatBubble.style.left=`${(bx*.5+.5)*canvas.clientWidth}px`;chatBubble.style.top=`${(.5-by*.5)*canvas.clientHeight}px`}
      const hp=[...dummy.overhead,1],clip=[0,1,2,3].map(r=>hp.reduce((sum,v,c)=>sum+vp[c*4+r]*v,0));
      const nx=clip[0]/clip[3],ny=clip[1]/clip[3],visible=clip[3]>0&&Math.abs(nx)<1.05&&Math.abs(ny)<1.05&&Math.hypot(player.x-dummy.center[0],player.y-dummy.center[1],player.z-dummy.center[2])<=100;
      overhead.hidden=!visible;
      if(visible){overhead.style.left=`${(nx*.5+.5)*canvas.clientWidth}px`;overhead.style.top=`${(.5-ny*.5)*canvas.clientHeight}px`;const ratio=Math.max(0,Math.min(1,dummy.health/dummy.maxHealth));overheadHealth.hidden=ratio>=1;overheadHealth.setAttribute('aria-valuenow',String(dummy.health));overheadFill.style.width=`${ratio*100}%`;const color=window.RobloxHealthResearch.colorForPercent(ratio);overheadFill.style.backgroundColor=`rgb(${color.map(x=>Math.round(x*255)).join(',')})`; }
      box(plateSize,scene.baseplate.center,0,[0.46,0.65,0.43,1],true);
      for(const step of Obstacles.stairs)box(step.size,step.center,0,[.64,.64,.65,1]);
      for(const part of Obstacles.chair.parts)box(part.size,part.center,0,[.48,.29,.16,1]);for(const part of Obstacles.ladder.parts)box(part.size,part.center,0,[.68,.68,.7,1]);box(Obstacles.platform.size,Obstacles.platform.center,0,[.55,.55,.58,1]);if(!carpetCollected)classicToolFrame('carpet0',R6Animation.yawFrame(...Obstacles.carpetPickup.center,0));
      for(const h of toolState.hazards)box(h.size,h.center,0,h.color);for(const wall of toolState.walls)boxFrame(wall.size,R6Animation.qmatrix(wall.rotation,wall.center),wall.color);for(const rocket of toolState.rockets)draw(cube,gl.TRIANGLES,36,[1,1,3],null,0,[.08,.32,.9,1],true,Tools.projectileFrame(rocket));
      if(dummy.health>0){
        for(const part of dummy.parts){if(part.name==='Head')linkedHeadFrame(R6Parts.headMeshScale,R6Animation.yawFrame(...part.center,Math.PI),[.78,.78,.78,1]);else box(part.size,part.center,0,[.55,.55,.58,1]);}
      }
      {
        for(const part of dummy.fallenParts){const model=R6Animation.qmatrix(part.rotation,part.center);if(part.name==='Head')linkedHeadFrame(R6Parts.headMeshScale,model,[.78,.78,.78,1]);else boxFrame(part.size,model,[.55,.55,.58,1]);}
      }
      if(!playerDeath&&player.y<8 && Math.abs(player.x)<plateHalfBounds[0] && Math.abs(player.z)<plateHalfBounds[2]){
        gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA); gl.depthMask(false);
        draw(disk,gl.TRIANGLE_FAN,42,[1.6,1,1.1],[player.x,0.015,player.z],0,[0.10,0.18,0.11,0.22*(1-player.y/10)],false);
        gl.depthMask(true); gl.disable(gl.BLEND);
      }
      const b=R6Parts.parts,skin=[245/255,205/255,48/255,1],shirt=[13/255,105/255,172/255,1],trousers=[164/255,189/255,71/255,1];
      if(playerDeath){
        for(const part of playerDeath.sim.getParts()){
          const model=R6Animation.qmatrix(part.rotation,part.center),color=part.name==='Torso'?shirt:part.name.includes('Leg')?trousers:skin;
          if(part.name==='Head')linkedHeadFrame(R6Parts.headMeshScale,model,color);else boxFrame(part.size,model,color);
        }
      }else if(camera.distance>=ClassicCamera.source.firstPersonThreshold){
        for(const [name,color] of [['Torso',shirt],['Left Arm',skin],['Right Arm',skin],['Left Leg',trousers],['Right Leg',trousers]])
          boxFrame(b[name].size,R6Animation.multiply(rootFrame,r6Matrices[name]),color);
        linkedHeadFrame(R6Parts.headMeshScale,R6Animation.multiply(rootFrame,r6Matrices.Head),skin);
      }
      if(!playerDeath){if(carpet.active){for(const f of carpet.frames(R6Animation,player,time))classicToolFrame(f.type,f.frame);}else if(window.__robloxBackpack.getState().equippedTool==='carpet')classicToolFrame('carpet0',classicModelFrame(rootFrame,'carpet'));if(weaponFrame)linkedSwordFrame(weaponFrame);const equippedTool=window.__robloxBackpack&&window.__robloxBackpack.getState().equippedTool;if((equippedTool==='trowel'||equippedTool==='rocket'||equippedTool==='pistol')&&camera.distance>=ClassicCamera.source.firstPersonThreshold)classicToolFrame(equippedTool,classicModelFrame(rootFrame,equippedTool));}
      gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);gl.depthMask(false);for(const r of carpet.ribbons(time))boxFrame(r.size,r.frame,r.color);gl.depthMask(true);gl.disable(gl.BLEND);
      if(!playerDeath&&time<forcefieldUntil)shieldRenderer.draw(vp,camera,[player.x,player.y+2.5,player.z],time);
      gun.refresh(time);for(const shot of gun.tracers()){const delta=shot.b.map((v,i)=>v-shot.a[i]),mid=shot.a.map((v,i)=>(v+shot.b[i])/2),m=Tools.projectileFrame({velocity:delta,position:mid});boxFrame([.07,.07,Math.hypot(...delta)],m,[1,.82,.12,.85])}
      explosionRenderer.draw(vp,camera,toolState.explosions,time);
    }
    const stepMemory=new ArrayBuffer(384*65536), stepView=new DataView(stepMemory);
    const stepWorld=4096, demoHz=240, demoStep=1/demoHz;
    stepView.setUint8(9113092,1); stepView.setUint8(stepWorld+452,1);
    stepView.setFloat32(stepWorld+1592,demoHz,true);
    const stepStats={frames:0,totalTicks:0,lastTicks:0};let perfTime=0,perfFrames=0;const perfDisplay=document.getElementById('rbx-performance-stats');
    function frame(now) {
      const dt=lastFrame ? Math.max((now-lastFrame)/1000,0) : 0; lastFrame=now;
      eventQueue.drain(dispatchKeyboardRecord); // 485 queue control + restricted 3213 path
      consumeDemoInput(); // not the original gameplay consumer
      const ticks=WorldSteps.plan(stepMemory,stepWorld,dt);
      stepStats.frames++; stepStats.totalTicks+=ticks; stepStats.lastTicks=ticks;
      const swordFrame=sword.tick(now/1000);if(queuedSword&&swordFrame.enabled&&swordFrame.equipped&&!playerDeath)activateSword();updateToolCursor(sword.getState());
      for(let i=0;i<ticks;i++)update(demoStep,swordFrame); // demo physics, NOT the WASM solver
      if(playerDeath){playerDeath.sim.step(dt,deathSurface,Obstacles.collisionParts);if(now/1000>=playerDeath.respawnAt)respawnPlayer()}
      const phase=carpet.active?'carpet':player.climbing?'climb':player.seated?'sit':!player.grounded?(player.jumpTime>0?'jump':'fall'):'ground';
      if(!playerDeath)r6Matrices=r6Animator.step(ticks*demoStep,player.climbing?player.climbSpeed:player.moving&&player.grounded?motionDefaults.walkSpeed:0,1,{phase,equipped:!!(window.__robloxBackpack&&window.__robloxBackpack.getState().equipped),emote:window.__emotes.current(player,now/1000),gun:gun.animation(now/1000)});
      render();const settings=window.__localSettings&&window.__localSettings.getState();perfDisplay.hidden=!(settings&&settings.performance);if(!perfDisplay.hidden){perfTime+=dt;perfFrames++;if(perfTime>=.5){perfDisplay.textContent='FPS '+Math.round(perfFrames/perfTime)+'   '+canvas.width+' × '+canvas.height;perfTime=0;perfFrames=0}}else{perfTime=0;perfFrames=0}requestAnimationFrame(frame);
    }
    window.__baseplate = {
      getState:()=>({player:{...player},health:localHealth,forcefield:{active:!playerDeath&&performance.now()/1000<forcefieldUntil,expiresAt:forcefieldUntil},death:playerDeath?{dead:true,startedAt:playerDeath.startedAt,respawnAt:playerDeath.respawnAt,parts:playerDeath.sim.getParts()}:{dead:false,parts:[]},camera:{...camera,focus:cameraFocus.slice(),eye:cameraEye.slice(),firstPerson:camera.distance<ClassicCamera.source.firstPersonThreshold},clickTarget:clickTarget&&{...clickTarget},pointerLocked:document.pointerLockElement===canvas,characterSoundCounts:{...characterSoundCounts}}),
      kill:diePlayer, takeDamage:takeLocalDamage,
      getAnimationState:()=>({ ...r6Animator.state(),parts:Object.fromEntries(Object.entries(r6Matrices).map(([name,m])=>[name,m.slice(12,15)])),rightArmMatrix:r6Matrices['Right Arm'].slice(),source:'archived R6 keyframes; browser interpolation and demo movement' }),
      getSwordState:()=>({...sword.getState(),cursor:cursorKind,soundAttempts:swordSoundAttempts,lastSound:lastSwordSound,lastSoundVolume:lastSwordVolume,masterVolume:window.__localAudio?window.__localAudio.volume:.5}),
      getObstacleState:()=>({stairs:Obstacles.stairs,chair:Obstacles.chair,ladder:Obstacles.ladder,platform:Obstacles.platform,carpetPickup:Obstacles.carpetPickup,carpetCollected,carpetFlying:carpet.active,source:'authored browser demo; contacts and seat welding approximated'}),
      getTargetState:()=>demoTarget.getState(),getGunState:()=>gun.getState(),
      getToolsState:()=>({...demoTools.getState(performance.now()/1000),textureLoaded:{trowel:extraGeometry.trowel.loaded,rocket:extraGeometry.rocket.loaded}}),
      getGroundTarget:(x,y)=>groundTarget(x,y),
      getInputState:()=>({read:eventQueue.view.getInt32(MainQueue.layout.READ,true),
        write:eventQueue.view.getInt32(MainQueue.layout.WRITE,true),dropped:eventQueue.view.getInt32(MainQueue.layout.DROPPED,true),
        forwarded:inputTelemetry.forwarded,filtered:inputTelemetry.filtered,modifiers:eventQueue.view.getInt32(inputObject+176,true),
        objectUpdates:inputTelemetry.objectUpdates,objectDispatches:inputTelemetry.objectDispatches}),
      getInputObjectState:(physical)=>{const at=demoInputObjects.get(physical);return at===undefined?null:{state:eventQueue.view.getInt32(at+112,true),physical:eventQueue.view.getInt32(at+172,true),logical:eventQueue.view.getInt32(at+108,true),mask:eventQueue.view.getInt32(at+156,true),repeat:eventQueue.view.getInt32(at+176,true)};},
      getResearchState:()=>({
        sceneSource:'authored demo; not an extracted place',
        r6Model:{source:R6Parts.source,sha256:R6Parts.modelSha256,parts:R6Parts.parts,rig:'six Motor6Ds from candidate archive morpherEditorR6',rigSha256:R6AnimationData.rigSha256,colors:'demo noob palette'},
        r6Animation:{source:R6AnimationData.animateSource,sourceSha256:R6AnimationData.animateSourceSha256,walkAssetId:R6AnimationData.clips.walk.assetId,walkSha256:R6AnimationData.clips.walk.sha256,idleAssetId:R6AnimationData.clips.idle.assetId,interpolation:'browser adapter; Roblox Animator not recovered',jumpAssetId:AirClips.jump.assetId,fallAssetId:AirClips.fall.assetId,sitAssetId:ActionClips.sit.assetId,toolAssets:[ActionClips.toolnone.assetId,ActionClips.toolslash.assetId,ActionClips.toollunge.assetId]},
        headMesh:{source:LinkedHead.source,assetId:LinkedHead.assetId,sha256:LinkedHead.sha256,vertices:headGeometry.vertexCount,triangles:headGeometry.triangleCount,transform:'archived Motor6D rig plus demo heading'},
        ownerHeadMesh:{source:TargetHead.source,sha256:TargetHead.sha256,vertices:targetHeadGeometry.vertexCount,triangles:targetHeadGeometry.triangleCount,displayed:false},
        faceTexture:{sha256:R6Face.sha256,loaded:faceLoaded},
        plateTexture:{atlasPath:StudTexture.atlasPath,atlasSha256:StudTexture.atlasSha256,tileSha256:StudTexture.tileSha256,loaded:studTextureLoaded,rendering:'64x64 decoded tile repeated in WebGL; UV scale and lighting are adapters'},
        camera:{source:ClassicCamera.source,focus:'user-requested near-head-bottom R6 root plus 1.1 studs; 1142 source uses 1.5',input:'browser input scaling; no Roblox spring or occlusion',firstPerson:'0.5 minimum and hide avatar approximation'},
        swordCursor:{script:'Linked Sword MouseIcon LocalScript',readyPath:CursorData.readyPath,waitPath:CursorData.waitPath,imageSource:CursorData.source,readySha256:CursorData.readySha256,waitSha256:CursorData.waitSha256},
        linkedSword:{assetId:SwordData.assetId,meshAssetId:SwordMesh.assetId,meshSha256:SwordMesh.sha256,triangleCount:swordGeometry.triangleCount,textureSha256:SwordData.textureSha256,textureLoaded:swordTextureLoaded,grip:'archived R6 attachment and public Tool Grip plus observed -90 degree R6 weld; not yet traced in WASM',attack:'source-script timing, animations, sounds and Blow checks adapted; training-dummy contacts and damage are approximations'},
        playerDeath:{source:'documented Humanoid classic BreakJointsOnDeath and default five-second Players.RespawnTime',physics:'six independent browser-approximated parts; no original death or contact solver recovered'},
        dummyDisplay:{name:'Dummy',healthDisplay:'DisplayWhenDamaged; color and projection approximated',breakJointsOnDeath:'six authored falling parts; not the Roblox physics solver',occlusion:'not implemented'},
        runningHeight:{source:runningHeight.source,branch:runningHeight.branch,plateTop:demoPlateTop,standingRootOffset,plateTarget:runningFloorTarget,contact:'demo approximation; full walking physics not recovered'},
        motion:{...motionDefaults,humanoidSource:'1145 content/avatar/characterR6NoFace.rbxm Humanoid WalkSpeed and JumpPower',gravitySource:'documented Workspace default; place gravity not recovered',swordGlide:'authored airborne-only gravity reduction, no grounded launch or horizontal force; not a reconstructed BodyVelocity solver',integration:'demo motion and synthetic contacts; not Roblox Humanoid physics'},
        plateSize:[...plateSize],shapeSize:[...shapeSize],halfBounds:[...plateHalfBounds],
        canCollide:plate.canCollide,spawnDefaults:spawnProperties.snapshot(),
        materialCode:scene.baseplate.material,materialField4:partBytes.getFloat32(primitiveAddress+452,true),
        shapeKind:partBytes.getUint8(primitiveAddress+339),volumeAndCenter:Block.volumeAndCenter(plateSize),
        stagedFiles:assetFS.snapshot().inline.length,
        faceQueryChecks,
        stepScheduler:{demoHz,capSetting:stepView.getInt32(9031000,true),frames:stepStats.frames,totalTicks:stepStats.totalTicks,lastTicks:stepStats.lastTicks,retained:stepView.getFloat32(stepWorld+228,true),dropped:stepView.getFloat32(stepWorld+284,true)},
        keyboardTrace:{keyW:Keyboard.fromLoaderDomCode('KeyW'),logicalW:Keyboard.logicalFromCode(Keyboard.fromLoaderDomCode('KeyW')),usableQueueEntries:MainQueue.layout.usable},
        limitations:'renderer, movement, world and physics are approximations'
      }),
      reset
    };
    requestAnimationFrame(frame);
  } catch (err) {
    console.error(err);
    showError('The offline baseplate could not start: '+(err && err.message ? err.message : String(err)));
  }
})();
