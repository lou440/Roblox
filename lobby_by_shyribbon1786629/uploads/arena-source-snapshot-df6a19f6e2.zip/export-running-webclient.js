#!/usr/bin/env node
/* Opt-in local Chrome DevTools Protocol exporter for an ALREADY-RUNNING tab.
   No browser launch, reload, profile modification, credential or network upload. */
'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const args=process.argv.slice(2),value=(flag,fallback)=>{const n=args.indexOf(flag);return n<0?fallback:args[n+1]},port=Number(value('--port','9222')),target=value('--target',''),wantJs=args.includes('--include-js'),wantText=args.includes('--disassemble'),max=Number(value('--max-modules','8'));
if(args.includes('--help')){console.log('node --experimental-websocket export-running-webclient.js [--port 9222] [--target ID-or-title] [--disassemble] [--include-js] [--max-modules 8]');process.exit(0)}
if(!Number.isInteger(port)||port<1024||port>65535||!Number.isInteger(max)||max<1||max>100){console.error('Invalid port or module limit.');process.exit(2)}
if(typeof WebSocket==='undefined'){console.error('Node WebSocket is unavailable; use Node 20+ with --experimental-websocket.');process.exit(2)}
const safeUrl=s=>{try{const u=new URL(s);return u.protocol+'//'+u.host+u.pathname}catch{return String(s||'').slice(0,250)}};
async function main(){
 const res=await fetch('http://127.0.0.1:'+port+'/json/list',{signal:AbortSignal.timeout(5000)});if(!res.ok)throw Error('Local debug endpoint returned HTTP '+res.status);const all=await res.json(),tabs=all.filter(x=>x.webSocketDebuggerUrl&&['page','iframe','worker','service_worker'].includes(x.type));
 const matches=target?tabs.filter(x=>x.id===target||(x.title||'').toLowerCase().includes(target.toLowerCase())||safeUrl(x.url).toLowerCase().includes(target.toLowerCase())):tabs.filter(x=>/roblox/i.test((x.title||'')+' '+(x.url||'')));
 if(matches.length!==1){console.log('Choose exactly one target using --target ID. Available local debug targets:');for(const x of tabs)console.log(x.id+'  '+x.type+'  '+(x.title||'').slice(0,100)+'  '+safeUrl(x.url));return}
 const tab=matches[0],wsurl=new URL(tab.webSocketDebuggerUrl);if(!['127.0.0.1','localhost','[::1]'].includes(wsurl.hostname)||Number(wsurl.port)!==port||wsurl.protocol!=='ws:')throw Error('Refusing a non-local debugging WebSocket.');
 const ws=new WebSocket(wsurl.href),pending=new Map(),scripts=[];let seq=0;
 ws.onmessage=e=>{let m;try{m=JSON.parse(e.data)}catch{return}if(m.method==='Debugger.scriptParsed'&&m.params)scripts.push(m.params);else if(m.id&&pending.has(m.id)){const p=pending.get(m.id);pending.delete(m.id);clearTimeout(p.timer);m.error?p.reject(Error(m.error.message||'CDP error')):p.resolve(m.result||{})}};
 await new Promise((resolve,reject)=>{ws.onopen=resolve;ws.onerror=()=>reject(Error('Could not connect to local debug target.'))});
 function call(method,params={},ms=120000){return new Promise((resolve,reject)=>{const id=++seq,timer=setTimeout(()=>{pending.delete(id);reject(Error(method+' timed out'))},ms);pending.set(id,{resolve,reject,timer});ws.send(JSON.stringify({id,method,params}))})}
 let out=null;const report={target:{id:tab.id,title:tab.title,url:safeUrl(tab.url),type:tab.type},created:new Date().toISOString(),modules:[],notes:['Running debug target only; no navigation/reload. Worker targets require a separate selected export.','Disassembly and source fidelity depend on the browser/CDP; huge modules may fail or take significant time.']};
 try{
  await call('Debugger.enable');await new Promise(r=>setTimeout(r,1200));const wasm=scripts.filter(x=>x.scriptLanguage==='WebAssembly'||String(x.url||'').startsWith('wasm://')),js=wantJs?scripts.filter(x=>x.scriptLanguage!=='WebAssembly'&&!String(x.url||'').startsWith('wasm://')):[];
  if(!wasm.length&&!js.length){console.log('No eligible parsed scripts in the selected target. The WebClient may be in another page or worker, or not running in this debug-enabled browser.');return}
  const stamp=new Date().toISOString().replace(/[:.]/g,'-');out=path.resolve('roblox-running-export-'+stamp);fs.mkdirSync(out,{recursive:false});
  for(const [i,s] of wasm.slice(0,max).entries()){
   const name='module-'+String(i+1).padStart(3,'0'),entry={scriptId:s.scriptId,url:safeUrl(s.url),hash:s.hash||null};report.modules.push(entry);
   try{const source=await call('Debugger.getScriptSource',{scriptId:s.scriptId});if(source.bytecode){const bytes=Buffer.from(source.bytecode,'base64');fs.writeFileSync(path.join(out,name+'.wasm'),bytes,{flag:'wx'});entry.bytes=bytes.length;entry.sha256=crypto.createHash('sha256').update(bytes).digest('hex')}else entry.bytecode='Not returned by this browser';}catch(e){entry.bytecodeError=e.message}
   if(wantText){let fd;try{fd=fs.openSync(path.join(out,name+'.wat.txt'),'wx');const d=await call('Debugger.disassembleWasmModule',{scriptId:s.scriptId});function write(chunk){if(chunk&&Array.isArray(chunk.lines))fs.writeSync(fd,chunk.lines.join('\n')+'\n')}write(d.chunk);if(d.streamId){for(;;){const next=await call('Debugger.nextWasmDisassemblyChunk',{streamId:d.streamId});write(next.chunk);if(!next.chunk||!next.chunk.lines||!next.chunk.lines.length)break}}entry.disassemblyLines=d.totalNumberOfLines??null}catch(e){entry.disassemblyError=e.message}finally{if(fd!==undefined)fs.closeSync(fd)}}
  }
  if(wantJs){fs.mkdirSync(path.join(out,'javascript'));report.javascript=[];for(const [i,s] of js.slice(0,500).entries()){try{const r=await call('Debugger.getScriptSource',{scriptId:s.scriptId});if(typeof r.scriptSource==='string'){const file='script-'+String(i+1).padStart(4,'0')+'.js';fs.writeFileSync(path.join(out,'javascript',file),r.scriptSource,{flag:'wx'});report.javascript.push({file,url:safeUrl(s.url),scriptId:s.scriptId})}}catch(e){report.javascript.push({scriptId:s.scriptId,error:e.message})}}}
  report.totalWasmScripts=wasm.length;fs.writeFileSync(path.join(out,'manifest.json'),JSON.stringify(report,null,2),{flag:'wx'});console.log('Saved local export:',out,'WASM modules:',report.modules.length,'of',wasm.length,'JavaScript:',report.javascript?.length||0);console.log('Review manifest.json for errors and limitations. Files may contain private code or data; they were not uploaded.');
 }finally{try{await call('Debugger.disable',{},5000)}catch{}ws.close()}
}
main().catch(e=>{console.error('Export failed:',e.message);process.exitCode=1});
