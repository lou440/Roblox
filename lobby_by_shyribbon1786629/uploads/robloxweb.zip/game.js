/* Offline research demo: selected JavaScript routines are traced from WASM.
 * Scene layout, renderer, controls, movement and physics remain approximations. */
(() => {
  'use strict';
  const canvas = document.getElementById('game');
  const errorBox = document.getElementById('error');
  const showError = (message) => { errorBox.hidden = false; errorBox.textContent = message; };
  const gl = canvas.getContext('webgl', {alpha: true, antialias: true, depth: true}) || canvas.getContext('experimental-webgl');
  if (!gl) { showError('This browser could not start WebGL. Enable hardware acceleration, or open this file in a recent Chrome, Edge, or Firefox.'); return; }

  try {
    const Block=window.WasmBlockGeometry, BlockFaceQuery=window.WasmBlockFaceQuery, PartView=window.WasmBasePartMemoryView;
    const SpawnState=window.WasmSpawnLocationState, AssetFS=window.WasmAssetFS;
    const Chain=window.WasmPrimitiveChain, Material=window.WasmMaterialProperties;
    const DetachedUpdate=window.WasmDetachedBlockUpdate;
    const MainQueue=window.WasmMainEventQueue, Keyboard=window.WasmKeyboardCode, KeyboardInput=window.WasmKeyboardInput;
    const InputVector=window.WasmInputEventVector, InputDispatch=window.WasmInputDispatch, KeyboardModifiers=window.WasmKeyboardModifierState;
    const WorldSteps=window.WasmWorldStepAccumulator, InputObjectTail=window.WasmInputObjectUpdateTail;
    const TargetHead=window.TargetHeadMesh, R6Parts=window.ArchivedR6Parts;
    const LinkedHead=window.LinkedR6HeadMesh, R6Face=window.ArchivedR6Face;
    const R6Animation=window.ArchivedR6Animation, R6AnimationData=window.ArchivedR6AnimationData;
    const RunningHeight=window.RunningHeightAdapter, SwordMesh=window.LinkedSwordMesh, SwordData=window.LinkedSwordData;
    const AirClips=window.ArchivedR6AirAnimationData, ActionClips=window.ArchivedR6ActionAnimationData;
    const SwordScript=window.LinkedSwordScript, SwordAudio=window.LinkedSwordAudio, SwordHit=window.LinkedSwordHit, DemoTarget=window.DemoTarget, Obstacles=window.DemoObstacles;
    if(!Block || !BlockFaceQuery || !PartView || !SpawnState || !AssetFS || !Chain || !Material || !DetachedUpdate || !MainQueue || !Keyboard || !KeyboardInput || !InputVector || !InputDispatch || !KeyboardModifiers || !WorldSteps || !InputObjectTail || !TargetHead || !R6Parts || !LinkedHead || !R6Face || !R6Animation || !R6AnimationData || !RunningHeight || !SwordMesh || !SwordData || !AirClips || !ActionClips || !SwordScript || !SwordAudio || !SwordHit || !DemoTarget || !Obstacles) throw new Error('A local research module did not load.');
    Object.assign(R6AnimationData.clips,AirClips,ActionClips);

    // The layout below is a demo scene, not an extracted place file. Staging
    // uses the traced inline-file port; snapshot readback is ordinary JS.
    const scenePath='/offline/baseplate.json';
    const authoredScene={baseplate:{size:[512,0.5,512],center:[0,-0.25,0],material:256}};
    const sceneBytes=new TextEncoder().encode(JSON.stringify(authoredScene));
    const assetFS=new AssetFS();
    if(assetFS.registerAsset(scenePath,sceneBytes.length)!==0 || assetFS.addFile(scenePath,sceneBytes)!==0)
      throw new Error('Could not stage the local demo scene.');
    const inline=assetFS.snapshot().inline[0];
    const scene=JSON.parse(new TextDecoder().decode(Uint8Array.from(inline.data)));

    // This is only the detached Block path with mocked host services. The
    // linked/world branches and surrounding simulation are not reconstructed.
    const partBuffer=new ArrayBuffer(8192), partBytes=new DataView(partBuffer);
    const partAddress=64, primitiveAddress=512, geometryAddress=2048, customRecordAddress=4096;
    partBytes.setUint32(partAddress+260,primitiveAddress,true);
    partBytes.setUint32(primitiveAddress+396,geometryAddress,true);
    partBytes.setUint32(geometryAddress,8074444,true);
    partBytes.setUint8(primitiveAddress+338,56); // primitive constructor's initial flag byte
    partBytes.setUint8(primitiveAddress+339,2);  // primitive constructor's Block kind
    partBytes.setUint32(primitiveAddress+416,customRecordAddress,true); // demo's empty custom-property record
    partBytes.setUint16(primitiveAddress+430,scene.baseplate.material,true);
    const plate=new PartView(partBuffer,partAddress);
    const sizeHooks=Block.detachedSizeHooks(partBuffer,{
      call114418(p){
        // 113691 returns zero for this deliberately unlinked primitive; the
        // nonzero branch of 114418 still needs the surrounding engine.
        const pointer=partBytes.getUint32(p+40,true), child=pointer?(pointer-8)>>>0:0;
        if(child)throw new Error('This demo cannot update a linked primitive.');
      },
      call114374(p){
        DetachedUpdate.apply(partBuffer,p,{
          lockHandle:0, mutex:value=>value,
          alloc(){throw new Error('This demo does not allocate connected node state.');},
          free(){throw new Error('This demo does not own connected node state.');}
        });
      }
    });
    plate.setPrimitiveSizeDetached(scene.baseplate.size,0,sizeHooks);
    const plateSize=plate.size;
    // The target-height calculation executes nine recovered WASM functions in
    // a restricted JS VM. The R6 branch, floor, offset and object image are
    // synthetic inputs; collision and the resulting movement remain demo glue.
    const runningHeight=RunningHeight.create(R6Parts.parts);
    const standingRootOffset=runningHeight.target(0,0);
    const demoPlateTop=scene.baseplate.center[1]+plateSize[1]/2;
    const runningFloorTarget=runningHeight.target(demoPlateTop,0);
    const shapeSize=[0,1,2].map(i=>partBytes.getFloat32(geometryAddress+4*i+4,true));
    const plateHalfBounds=Block.rotatedHalfExtents(shapeSize,[1,0,0,0,1,0,0,0,1]);
    const spawnProperties=new SpawnState();
    const defaults=spawnProperties.snapshot();


    const derivatives = !!gl.getExtension('OES_standard_derivatives');
    const vertexSource = `
      attribute vec3 aPosition;
      attribute vec3 aNormal;
      attribute vec2 aUV;
      uniform mat4 uViewProjection;
      uniform vec3 uScale;
      uniform mat4 uModel;
      varying vec3 vWorld;
      varying vec3 vNormal;
      varying vec2 vUV;
      void main() {
        vUV = aUV;
        vec3 q = aPosition * uScale;
        vWorld = (uModel * vec4(q, 1.0)).xyz;
        vNormal = normalize(mat3(uModel) * aNormal);
        gl_Position = uViewProjection * vec4(vWorld, 1.0);
      }`;
    const fragmentSource = (derivatives ? '#extension GL_OES_standard_derivatives : enable\n' : '') + `
      precision highp float;
      uniform vec4 uColor;
      uniform float uFloor;
      uniform vec3 uCamera;
      uniform sampler2D uFace;
      uniform float uUseFace;
      varying vec3 vWorld;
      varying vec3 vNormal;
      varying vec2 vUV;
      void main() {
        vec3 n = normalize(vNormal);
        vec4 face = texture2D(uFace,vUV);
        vec3 color = mix(uColor.rgb,face.rgb,face.a*uUseFace);
        if (uFloor > 0.5 && n.y > 0.5) {
          float footprint = ${derivatives ? 'max(fwidth(vWorld.x), fwidth(vWorld.z))' : '0.10'};
          float detail = 1.0 - smoothstep(0.12, 1.05, footprint);
          vec2 grid = abs(fract(vWorld.xz / 4.0) - 0.5);
          float edge = max(smoothstep(0.476, 0.498, grid.x), smoothstep(0.476, 0.498, grid.y));
          float checker = mod(floor(vWorld.x / 4.0) + floor(vWorld.z / 4.0), 2.0);
          vec2 studPos = fract(vWorld.xz / 2.0) - 0.5;
          float r = length(studPos);
          float stud = 1.0 - smoothstep(0.17, 0.22, r);
          float rim = smoothstep(0.145, 0.195, r) * stud;
          color += (checker - 0.5) * 0.014;
          color *= 1.0 - edge * 0.11 * detail;
          color += (stud * 0.046 - rim * 0.045) * detail;
        }
        float light = 0.73 + 0.27 * max(dot(n, normalize(vec3(-0.40, 0.88, 0.26))), 0.0);
        color *= light;
        float fog = smoothstep(95.0, 370.0, length(vWorld - uCamera));
        color = mix(color, vec3(0.72, 0.83, 0.85), fog * 0.85);
        gl_FragColor = vec4(color, uColor.a);
      }`;

    function compile(type, source) {
      const shader = gl.createShader(type); gl.shaderSource(shader, source); gl.compileShader(shader);
      if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(shader) || 'Shader compilation failed');
      return shader;
    }
    const program = gl.createProgram();
    gl.attachShader(program, compile(gl.VERTEX_SHADER, vertexSource));
    gl.attachShader(program, compile(gl.FRAGMENT_SHADER, fragmentSource));
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(program) || 'Shader linking failed');
    gl.useProgram(program);
    const loc = {};
    for (const n of ['uViewProjection', 'uScale', 'uModel', 'uColor', 'uFloor', 'uCamera', 'uFace', 'uUseFace']) loc[n] = gl.getUniformLocation(program, n);
    const pos = gl.getAttribLocation(program, 'aPosition'), normal = gl.getAttribLocation(program, 'aNormal'), uv = gl.getAttribLocation(program, 'aUV');
    gl.enableVertexAttribArray(pos); gl.enableVertexAttribArray(normal);

    const vertices = [];
    function face(n, a, b, c, d) {
      for (const point of [a,b,c,a,c,d]) vertices.push(...point, ...n);
    }
    // Corners, face order and normals are recovered Block geometry. Splitting
    // each quad into triangles here is a demo-renderer choice, not a traced shader.
    for(let side=0;side<Block.faceCount;side++){
      const corners=Block.faceVertices([1,1,1],side), n=Block.facePlane([1,1,1],side).slice(0,3);
      face(n,...corners);
    }
    const cube = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, cube); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);
    // The archived R6 model references a different head than the separately
    // provided owner head. The linked public asset is the displayed mesh.
    const targetHeadGeometry=TargetHead.geometry(),headGeometry=LinkedHead.geometry();
    const headBuffer=gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER,headBuffer); gl.bufferData(gl.ARRAY_BUFFER,headGeometry.vertices,gl.STATIC_DRAW);
    const headUVs=gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER,headUVs); gl.bufferData(gl.ARRAY_BUFFER,headGeometry.uvs,gl.STATIC_DRAW);
    const headIndices=gl.createBuffer(); gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,headIndices); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,headGeometry.indices,gl.STATIC_DRAW);
    const faceTexture=gl.createTexture();let faceLoaded=false;
    gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,faceTexture);
    gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,1,1,0,gl.RGBA,gl.UNSIGNED_BYTE,new Uint8Array([0,0,0,0]));
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
    const faceImage=new Image();faceImage.onload=()=>{gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,faceTexture);gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,false);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,faceImage);faceLoaded=true};
    faceImage.src=R6Face.dataUri;gl.uniform1i(loc.uFace,0);
    // Linked Sword mesh, texture, Grip and R6 RightGripAttachment are from
    // public Roblox assets. This weld and the renderer are still adapters.
    const swordGeometry=SwordMesh.geometry(),swordBuffer=gl.createBuffer(),swordUVs=gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER,swordBuffer);gl.bufferData(gl.ARRAY_BUFFER,swordGeometry.vertices,gl.STATIC_DRAW);
    gl.bindBuffer(gl.ARRAY_BUFFER,swordUVs);gl.bufferData(gl.ARRAY_BUFFER,swordGeometry.uvs,gl.STATIC_DRAW);
    const swordTexture=gl.createTexture();gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,swordTexture);
    gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,1,1,0,gl.RGBA,gl.UNSIGNED_BYTE,new Uint8Array([255,255,255,255]));
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
    let swordTextureLoaded=false;const swordImage=new Image();swordImage.onload=()=>{gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,swordTexture);gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,false);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,swordImage);swordTextureLoaded=true};swordImage.src=SwordData.textureData;
    const diskData = [0,0,0, 0,1,0];
    for (let i=0; i<=40; i++) { const a=i*Math.PI*2/40; diskData.push(Math.cos(a),0,Math.sin(a), 0,1,0); }
    const disk = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, disk); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(diskData), gl.STATIC_DRAW);
    function buffer(which) {
      gl.bindBuffer(gl.ARRAY_BUFFER, which);
      gl.vertexAttribPointer(pos, 3, gl.FLOAT, false, 24, 0);
      gl.vertexAttribPointer(normal, 3, gl.FLOAT, false, 24, 12);
    }
    function draw(which, mode, count, scale, translation, yaw, color, floor, modelFrame) {
      buffer(which);gl.disableVertexAttribArray(uv);gl.vertexAttrib2f(uv,0,0);gl.uniform1f(loc.uUseFace,0);
      gl.uniform3fv(loc.uScale,scale);
      const frame=modelFrame||R6Animation.yawFrame(translation[0],translation[1],translation[2],yaw);
      gl.uniformMatrix4fv(loc.uModel,false,new Float32Array(frame));gl.uniform4fv(loc.uColor,color);gl.uniform1f(loc.uFloor,floor?1:0);
      gl.drawArrays(mode,0,count);
    }
    function box(scale,at,yaw,color,floor=false){draw(cube,gl.TRIANGLES,36,scale,at,yaw,color,floor)}
    function boxFrame(scale,modelFrame,color){draw(cube,gl.TRIANGLES,36,scale,null,0,color,false,modelFrame)}
    function linkedHeadFrame(scale,modelFrame,color) {
      buffer(headBuffer);gl.bindBuffer(gl.ARRAY_BUFFER,headUVs);gl.enableVertexAttribArray(uv);gl.vertexAttribPointer(uv,2,gl.FLOAT,false,8,0);
      gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,faceTexture);gl.uniform1f(loc.uUseFace,1);
      gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,headIndices);
      gl.uniform3fv(loc.uScale,scale);gl.uniformMatrix4fv(loc.uModel,false,new Float32Array(modelFrame));
      gl.uniform4fv(loc.uColor,color);gl.uniform1f(loc.uFloor,0);gl.drawElements(gl.TRIANGLES,headGeometry.indices.length,gl.UNSIGNED_SHORT,0);
    }
    function linkedSwordFrame(modelFrame){
      buffer(swordBuffer);gl.bindBuffer(gl.ARRAY_BUFFER,swordUVs);gl.enableVertexAttribArray(uv);gl.vertexAttribPointer(uv,2,gl.FLOAT,false,8,0);
      gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,swordTexture);gl.uniform1f(loc.uUseFace,1);
      gl.uniform3fv(loc.uScale,[1,1,1]);gl.uniformMatrix4fv(loc.uModel,false,new Float32Array(modelFrame));gl.uniform4fv(loc.uColor,[1,1,1,1]);gl.uniform1f(loc.uFloor,0);
      gl.drawArrays(gl.TRIANGLES,0,swordGeometry.vertexCount);
    }
    function perspective(fovy, aspect, near, far) {
      const f=1/Math.tan(fovy/2), out=new Float32Array(16);
      out[0]=f/aspect; out[5]=f; out[10]=(far+near)/(near-far); out[11]=-1; out[14]=2*far*near/(near-far); return out;
    }
    function lookAt(eye, center) {
      let zx=eye[0]-center[0], zy=eye[1]-center[1], zz=eye[2]-center[2];
      let l=Math.hypot(zx,zy,zz)||1; zx/=l; zy/=l; zz/=l;
      let xx=zz, xy=0, xz=-zx; l=Math.hypot(xx,xy,xz)||1; xx/=l; xy/=l; xz/=l;
      const yx=zy*xz-zz*xy, yy=zz*xx-zx*xz, yz=zx*xy-zy*xx;
      return new Float32Array([xx,yx,zx,0, xy,yy,zy,0, xz,yz,zz,0,
        -(xx*eye[0]+xy*eye[1]+xz*eye[2]), -(yx*eye[0]+yy*eye[1]+yz*eye[2]), -(zx*eye[0]+zy*eye[1]+zz*eye[2]), 1]);
    }
    function multiply(a,b) {
      const o=new Float32Array(16);
      for(let col=0;col<4;col++) for(let row=0;row<4;row++)
        o[col*4+row]=a[row]*b[col*4]+a[4+row]*b[col*4+1]+a[8+row]*b[col*4+2]+a[12+row]*b[col*4+3];
      return o;
    }

    // The ring and restricted 3213 path use a private single-threaded image.
    // Resolution, locking and the adapter from records to movement are demo glue.
    const inputMemory=new ArrayBuffer(MainQueue.layout.READ+4), eventQueue=new MainQueue(inputMemory);
    const keyboardInput=new KeyboardInput(eventQueue), inputContext=1024, inputObject=8192, inputScratch=4096;
    const inputVector=inputObject+136, inputStorage=16384, inputCapacity=MainQueue.layout.usable;
    eventQueue.view.setInt32(inputVector,inputStorage,true);
    eventQueue.view.setInt32(inputVector+4,inputStorage,true);
    eventQueue.view.setInt32(inputVector+8,inputStorage+12*inputCapacity,true);
    const inputHooks={lock(){},unlock(){},resolve(context,name){
      if(context!==inputContext||name!==InputDispatch.NAME)throw new Error('Unexpected demo input context');
      return inputObject;
    },alloc(){throw new Error('The demo input vector capacity was exceeded');},free(){throw new Error('The demo input vector does not own dynamic memory');}};
    const inputTelemetry={forwarded:0,filtered:0,objectUpdates:0,objectDispatches:0};
    // Synthetic per-key objects stand in for 99505's untraced lookup and
    // ownership. Setter side effects and notification/signal hooks are mocked.
    const demoInputObjects=new Map(); let nextDemoInputObject=32768;
    const objectHooks={setState(v,p,x){v.setInt32(p+20,x,true);},setLogical(v,p,x){v.setInt32(p+16,x,true);},notify(){},signal(){}};
    function demoObjectFor(physical){
      if(!demoInputObjects.has(physical)){
        if(nextDemoInputObject+256>4_000_000)throw new Error('Demo input object capacity exceeded');
        const address=nextDemoInputObject; nextDemoInputObject+=256;
        eventQueue.bytes.fill(0,address,address+256);
        eventQueue.view.setInt32(address+112,2,true); // demo initial released state
        demoInputObjects.set(physical,address);
      }
      return demoInputObjects.get(physical);
    }
    function clearDemoInputObjects(){demoInputObjects.clear();nextDemoInputObject=32768;}
    const demoKeys=new Map([[119,'KeyW'],[97,'KeyA'],[115,'KeyS'],[100,'KeyD'],
      [273,'ArrowUp'],[276,'ArrowLeft'],[274,'ArrowDown'],[275,'ArrowRight'],[32,'Space']]);
    const held=new Set();
    const player={x:0,y:0,z:0,vy:0,grounded:true,yaw:0,walk:0,moving:false,seated:false,seatCooldown:0,seatLock:false,jumpTime:0};
    const r6Animator=R6Animation.create(R6AnimationData),sword=SwordScript.create(),demoTarget=DemoTarget.create();let r6Matrices=r6Animator.step(0,0);
    let swordSoundAttempts=0,lastSwordSound=null,lastSwordVolume=null;const activeSwordSounds=new Set();
    window.addEventListener('hud:volume-changed',e=>{for(const sound of activeSwordSounds)sound.audio.volume=clamp(sound.base*e.detail.volume,0,1)});
    function playSwordSound(name){
      const source=SwordAudio[name];if(!source)return;lastSwordSound=name;swordSoundAttempts++;
      try{const audio=new Audio(source.dataUri),master=window.__localAudio?window.__localAudio.volume:.5,playing={audio,base:source.volume};audio.volume=clamp(source.volume*master,0,1);lastSwordVolume=audio.volume;activeSwordSounds.add(playing);audio.addEventListener('ended',()=>activeSwordSounds.delete(playing),{once:true});const play=audio.play();if(play&&play.catch)play.catch(()=>activeSwordSounds.delete(playing));}catch(e){}
    }
    function activateSword(){
      if(window.__hudInteraction&&window.__hudInteraction.blocksGameplay(canvas))return;
      const action=sword.activate(performance.now()/1000);if(!action.accepted)return;
      r6Animator.triggerToolAction(action.toolanim);playSwordSound(action.sound);
    }
    window.addEventListener('backpack:changed',e=>{const sound=sword.equip(!!e.detail.equipped);if(sound)playSwordSound(sound)});
    const camera={yaw:0.45,pitch:0.43,distance:17};
    let jumpQueued=false, lastFrame=0, dragging=false, pointerId=null, lastX=0, lastY=0,downX=0,downY=0,downButton=-1,pointerMoved=false;
    const clamp=(v,min,max)=>Math.max(min,Math.min(max,v));
    function reset() {
      Object.assign(player,{x:0,y:0,z:0,vy:0,grounded:true,yaw:0,walk:0,moving:false,seated:false,seatCooldown:0,seatLock:false,jumpTime:0});
      r6Animator.reset();sword.reset();demoTarget.reset();r6Matrices=r6Animator.step(0,0);
      if(window.__robloxBackpack)window.__robloxBackpack.unequip();
      Object.assign(camera,{yaw:0.45,pitch:0.43,distance:17}); held.clear(); jumpQueued=false; clearDemoInputObjects();
      if(window.__robloxHudResearch)window.__robloxHudResearch.setHealth(100,100,false,true);
    }
    const controlled=new Set(['KeyW','KeyA','KeyS','KeyD','ArrowUp','ArrowLeft','ArrowDown','ArrowRight','Space']);
    window.addEventListener('keydown', e => {
      if (window.__hudInteraction && window.__hudInteraction.blocksGameplay(e.target)) return;
      if (e.target && e.target.closest && e.target.closest('button') && e.code==='Space') return;
      if (controlled.has(e.code)) e.preventDefault();
      keyboardInput.handle(2,e);
    });
    window.addEventListener('keyup', e => { if(window.__hudInteraction && window.__hudInteraction.blocksGameplay(e.target)) return; keyboardInput.handle(3,e); });
    window.addEventListener('hud:control-suspend',()=>{eventQueue.drain(()=>{});eventQueue.view.setInt32(inputVector+4,inputStorage,true);held.clear();jumpQueued=false;clearDemoInputObjects();eventQueue.view.setInt32(inputObject+176,0,true);dragging=false;});
    window.addEventListener('blur', () => { eventQueue.drain(()=>{}); held.clear(); clearDemoInputObjects(); eventQueue.view.setInt32(inputObject+176,0,true); dragging=false; }); // demo focus cleanup
    function dispatchKeyboardRecord(address,record) {
      if(record[0]!==0)return;
      const physical=eventQueue.view.getInt32(address+8,true);
      const kept=InputDispatch.dispatch(inputMemory,inputContext,inputScratch,record[4],physical,
        Keyboard.logicalFromCode(physical),record[12],inputHooks);
      if(kept)inputTelemetry.forwarded++;else inputTelemetry.filtered++;
    }
    function consumeDemoInput() {
      const view=eventQueue.view,end=view.getInt32(inputVector+4,true);
      for(let at=inputStorage;at<end;at+=12){
        KeyboardModifiers.apply(inputMemory,inputObject,at); // 3107 modifier-mask switch
        const down=view.getUint8(at)!==0,repeat=view.getUint8(at+1)!==0;
        const physical=view.getInt32(at+8,true),logical=view.getInt32(at+4,true);
        const gate=InputObjectTail.update(inputMemory,demoObjectFor(physical),down,repeat,physical,logical,view.getInt32(inputObject+176,true),objectHooks);
        inputTelemetry.objectUpdates++; if(gate)inputTelemetry.objectDispatches++;
        const key=demoKeys.get(logical);
        if(!key||!gate)continue; // demo adapter; 92288 itself is not recovered
        if(down){if(key==='Space'&&!repeat)jumpQueued=true;held.add(key);}else held.delete(key);
      }
      // Consuming/resetting the vector here is demo glue, not a traced consumer.
      view.setInt32(inputVector+4,inputStorage,true);
    }
    canvas.addEventListener('pointerdown', e => {
      if (e.button!==0 && e.button!==2) return;
      dragging=true; pointerId=e.pointerId;lastX=downX=e.clientX;lastY=downY=e.clientY;downButton=e.button;pointerMoved=false;
      canvas.setPointerCapture(e.pointerId); canvas.focus({preventScroll:true}); e.preventDefault();
    });
    canvas.addEventListener('pointermove', e => {
      if (!dragging || e.pointerId!==pointerId) return;
      if(Math.hypot(e.clientX-downX,e.clientY-downY)>6)pointerMoved=true;
      const sensitivity=window.__hudInteraction?window.__hudInteraction.sensitivity:1;
      camera.yaw -= (e.clientX-lastX)*0.0065*sensitivity;
      camera.pitch=clamp(camera.pitch+(e.clientY-lastY)*0.005*sensitivity,0.10,1.22);
      lastX=e.clientX; lastY=e.clientY;
    });
    function endPointer(e) { if(e.pointerId===pointerId){if(e.type==='pointerup'&&downButton===0&&!pointerMoved)activateSword();dragging=false;pointerId=null;} }
    canvas.addEventListener('pointerup',endPointer); canvas.addEventListener('pointercancel',endPointer); canvas.addEventListener('lostpointercapture',endPointer);
    canvas.addEventListener('contextmenu',e=>e.preventDefault());
    canvas.addEventListener('wheel',e=>{ e.preventDefault(); camera.distance=clamp(camera.distance*Math.exp(e.deltaY*0.001),7,44); },{passive:false});
    for (const button of document.querySelectorAll('[data-touch]')) {
      const key=button.dataset.touch;
      button.addEventListener('pointerdown',e=>{ e.preventDefault(); if(window.__hudInteraction&&window.__hudInteraction.blocksGameplay(e.target))return; button.setPointerCapture(e.pointerId); if(key==='Space') jumpQueued=true; else held.add(key); });
      const release=()=>held.delete(key);
      button.addEventListener('pointerup',release); button.addEventListener('pointercancel',release); button.addEventListener('lostpointercapture',release);
    }
    let faceQueryChecks=0;
    function update(dt,swordFrame) {
      player.seatCooldown=Math.max(0,player.seatCooldown-dt);
      player.jumpTime=Math.max(0,player.jumpTime-dt);
      if(player.seated){
        player.moving=false;
        if(jumpQueued){player.seated=false;player.seatLock=true;player.seatCooldown=1;player.y=Obstacles.chair.seatTop;player.vy=9;player.grounded=false;player.jumpTime=.3;}
        else {jumpQueued=false;return;}
      }
      const forward=(held.has('KeyW')||held.has('ArrowUp')?1:0)-(held.has('KeyS')||held.has('ArrowDown')?1:0);
      const side=(held.has('KeyD')||held.has('ArrowRight')?1:0)-(held.has('KeyA')||held.has('ArrowLeft')?1:0);
      let dx=-Math.sin(camera.yaw)*forward+Math.cos(camera.yaw)*side;
      let dz=-Math.cos(camera.yaw)*forward-Math.sin(camera.yaw)*side;
      const length=Math.hypot(dx,dz);
      player.moving=length>0;
      if(length>0){
        dx/=length;dz/=length;const x=player.x+dx*11*dt,z=player.z+dz*11*dt;
        if(!Obstacles.blocked(x,z,player.y,player.grounded)){player.x=x;player.z=z;}
        else player.moving=false;
        player.yaw=Math.atan2(dx,dz);if(player.moving)player.walk+=dt*9;
      }
      faceQueryChecks++;
      const overPlate=plate.canCollide&&BlockFaceQuery.projectionInside(plateSize,1,[player.x-scene.baseplate.center[0],player.y-scene.baseplate.center[1],player.z-scene.baseplate.center[2]]);
      const stairHeight=Obstacles.stairTop(player.x,player.z);
      const ground=overPlate?Math.max(runningFloorTarget-standingRootOffset,stairHeight??-Infinity):stairHeight;
      // Synthetic step-up and contact logic. This is NOT the Roblox solver.
      if(player.grounded&&ground!==null&&ground>player.y&&ground-player.y<=.751)player.y=ground;
      if(jumpQueued&&player.grounded){player.vy=9;player.grounded=false;player.jumpTime=.3;}
      jumpQueued=false;
      if(swordFrame.forceUp){player.vy=Math.max(player.vy,10);player.grounded=false;}
      player.vy-=22*dt;player.y+=player.vy*dt;
      if(ground!==null&&player.vy<=0&&player.y<=ground){player.y=ground;player.vy=0;player.grounded=true;}else player.grounded=false;
      if(player.seatLock&&(Math.abs(player.x-Obstacles.chair.center[0])>1.7||Math.abs(player.z-Obstacles.chair.center[1])>1.7))player.seatLock=false;
      // Seat activation/welding is an authored proximity adapter, not Seat code.
      if(!player.seatLock&&!swordFrame.forceUp&&Obstacles.seatCandidate(player.x,player.z,player.y,player.grounded,player.seatCooldown)){
        player.seated=true;player.x=Obstacles.chair.center[0];player.z=Obstacles.chair.center[1];player.y=Obstacles.chair.seatTop-2;player.yaw=Obstacles.chair.yaw;player.vy=0;player.grounded=true;player.moving=false;player.jumpTime=0;
      }
      if(player.y < -40)reset();
    }
    function resize() {
      const dpr=Math.min(window.devicePixelRatio||1,2);
      const w=Math.max(1,Math.round(canvas.clientWidth*dpr)), h=Math.max(1,Math.round(canvas.clientHeight*dpr));
      if(canvas.width!==w || canvas.height!==h){ canvas.width=w; canvas.height=h; }
      gl.viewport(0,0,w,h);
    }
    function swordModelFrame(rootFrame){
      if(!sword.getState().equipped)return null;
      const arm=R6Animation.multiply(rootFrame,r6Matrices['Right Arm']);
      // Community-observed R6 weld convention; not traced in this WASM.
      const attachment=R6Animation.fromCFrame(SwordData.rightGripAttachment);
      const r6WeldRotation=R6Animation.fromCFrame({position:[0,0,0],rotation:[1,0,0,0,0,1,0,-1,0]});
      const hand=R6Animation.multiply(attachment,r6WeldRotation),grip=R6Animation.inverseRigid(R6Animation.fromCFrame(SwordScript.grips[sword.getState().grip]));
      return R6Animation.multiply(R6Animation.multiply(arm,hand),grip);
    }
    function render() {
      resize();
      const rootFrame=R6Animation.yawFrame(player.x,player.y+standingRootOffset,player.z,player.yaw+Math.PI),weaponFrame=swordModelFrame(rootFrame);
      // Authored swept-line contact; this does NOT reproduce Roblox Touched.
      demoTarget.step(performance.now()/1000,weaponFrame,sword.getState());const dummy=demoTarget.getState();
      gl.clearColor(0,0,0,0); gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT); gl.enable(gl.DEPTH_TEST); gl.depthFunc(gl.LEQUAL);
      const cp=Math.cos(camera.pitch), target=[player.x,player.y+2.2,player.z];
      const eye=[target[0]+Math.sin(camera.yaw)*cp*camera.distance, target[1]+Math.sin(camera.pitch)*camera.distance, target[2]+Math.cos(camera.yaw)*cp*camera.distance];
      gl.uniformMatrix4fv(loc.uViewProjection,false,multiply(perspective(Math.PI/3,canvas.width/canvas.height,0.1,800),lookAt(eye,target)));
      gl.uniform3fv(loc.uCamera,eye);
      box(plateSize,scene.baseplate.center,0,[0.46,0.65,0.43,1],true);
      for(const step of Obstacles.stairs)box(step.size,step.center,0,[.64,.64,.65,1]);
      for(const part of Obstacles.chair.parts)box(part.size,part.center,0,[.48,.29,.16,1]);
      // Authored stationary R6-shaped target. The original place was not recovered.
      if(dummy.health>0){
        for(const part of dummy.parts){if(part.name==='Head')linkedHeadFrame(R6Parts.headMeshScale,R6Animation.yawFrame(...part.center,Math.PI),[.78,.78,.78,1]);else box(part.size,part.center,0,[.55,.55,.58,1]);}
        box([2.4,.18,.12],[dummy.center[0],5.65,dummy.center[2]],0,[.12,.12,.13,1]);
        const healthWidth=2.3*dummy.health/dummy.maxHealth;if(healthWidth>0)box([healthWidth,.12,.16],[dummy.center[0]-1.15+healthWidth/2,5.65,dummy.center[2]+.01],0,[.20,.85,.25,1]);
      }
      if(player.y<8 && Math.abs(player.x)<plateHalfBounds[0] && Math.abs(player.z)<plateHalfBounds[2]){
        gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA); gl.depthMask(false);
        draw(disk,gl.TRIANGLE_FAN,42,[1.6,1,1.1],[player.x,0.015,player.z],0,[0.10,0.18,0.11,0.22*(1-player.y/10)],false);
        gl.depthMask(true); gl.disable(gl.BLEND);
      }
      // Archived R6 Motor6D C0/C1 and decoded keyframes drive every part.
      // Matrix interpolation/blending and moving-speed input are demo adapters.
      // Archived R6 faces -Z; demo heading zero points +Z.
      const b=R6Parts.parts,skin=[245/255,205/255,48/255,1],shirt=[13/255,105/255,172/255,1],trousers=[164/255,189/255,71/255,1];
      for(const [name,color] of [['Torso',shirt],['Left Arm',skin],['Right Arm',skin],['Left Leg',trousers],['Right Leg',trousers]])
        boxFrame(b[name].size,R6Animation.multiply(rootFrame,r6Matrices[name]),color);
      linkedHeadFrame(R6Parts.headMeshScale,R6Animation.multiply(rootFrame,r6Matrices.Head),skin);
      if(weaponFrame)linkedSwordFrame(weaponFrame);
    }
    // Only the normal 89079 accumulator is recovered. Its selected flag and
    // object state are seeded here; the 240 Hz rate and 0 cap value are demo
    // choices, not proven defaults of the target build. Every scheduled tick
    // still runs the independently written, approximate character update.
    const stepMemory=new ArrayBuffer(384*65536), stepView=new DataView(stepMemory);
    const stepWorld=4096, demoHz=240, demoStep=1/demoHz;
    stepView.setUint8(9113092,1); stepView.setUint8(stepWorld+452,1);
    stepView.setFloat32(stepWorld+1592,demoHz,true);
    const stepStats={frames:0,totalTicks:0,lastTicks:0};
    function frame(now) {
      const dt=lastFrame ? Math.max((now-lastFrame)/1000,0) : 0; lastFrame=now;
      eventQueue.drain(dispatchKeyboardRecord); // 485 queue control + restricted 3213 path
      consumeDemoInput(); // not the original gameplay consumer
      const ticks=WorldSteps.plan(stepMemory,stepWorld,dt);
      stepStats.frames++; stepStats.totalTicks+=ticks; stepStats.lastTicks=ticks;
      const swordFrame=sword.tick(now/1000);
      for(let i=0;i<ticks;i++)update(demoStep,swordFrame); // demo physics, NOT the WASM solver
      const phase=player.seated?'sit':!player.grounded?(player.jumpTime>0?'jump':'fall'):'ground';
      r6Matrices=r6Animator.step(ticks*demoStep,player.moving&&player.grounded?11:0,1,{phase,equipped:swordFrame.equipped});
      render(); requestAnimationFrame(frame);
    }
    window.__baseplate = {
      getState:()=>({player:{...player},camera:{...camera}}),
      getAnimationState:()=>({ ...r6Animator.state(),parts:Object.fromEntries(Object.entries(r6Matrices).map(([name,m])=>[name,m.slice(12,15)])),rightArmMatrix:r6Matrices['Right Arm'].slice(),source:'archived R6 keyframes; browser interpolation and demo movement' }),
      getSwordState:()=>({...sword.getState(),soundAttempts:swordSoundAttempts,lastSound:lastSwordSound,lastSoundVolume:lastSwordVolume,masterVolume:window.__localAudio?window.__localAudio.volume:.5}),
      getObstacleState:()=>({stairs:Obstacles.stairs,chair:Obstacles.chair,source:'authored browser demo; contacts and seat welding approximated'}),
      getTargetState:()=>demoTarget.getState(),
      getInputState:()=>({read:eventQueue.view.getInt32(MainQueue.layout.READ,true),
        write:eventQueue.view.getInt32(MainQueue.layout.WRITE,true),dropped:eventQueue.view.getInt32(MainQueue.layout.DROPPED,true),
        forwarded:inputTelemetry.forwarded,filtered:inputTelemetry.filtered,modifiers:eventQueue.view.getInt32(inputObject+176,true),
        objectUpdates:inputTelemetry.objectUpdates,objectDispatches:inputTelemetry.objectDispatches}),
      getInputObjectState:(physical)=>{const at=demoInputObjects.get(physical);return at===undefined?null:{state:eventQueue.view.getInt32(at+112,true),physical:eventQueue.view.getInt32(at+172,true),logical:eventQueue.view.getInt32(at+108,true),mask:eventQueue.view.getInt32(at+156,true),repeat:eventQueue.view.getInt32(at+176,true)};},
      getResearchState:()=>({
        sceneSource:'authored demo; not an extracted place',
        r6Model:{source:R6Parts.source,sha256:R6Parts.modelSha256,parts:R6Parts.parts,rig:'six Motor6Ds from candidate archive morpherEditorR6',rigSha256:R6AnimationData.rigSha256,colors:'demo noob palette'},
        r6Animation:{source:R6AnimationData.animateSource,sourceSha256:R6AnimationData.animateSourceSha256,walkAssetId:R6AnimationData.clips.walk.assetId,walkSha256:R6AnimationData.clips.walk.sha256,idleAssetId:R6AnimationData.clips.idle.assetId,interpolation:'browser adapter; Roblox Animator not recovered',jumpAssetId:AirClips.jump.assetId,fallAssetId:AirClips.fall.assetId,sitAssetId:ActionClips.sit.assetId,toolAssets:[ActionClips.toolnone.assetId,ActionClips.toolslash.assetId,ActionClips.toollunge.assetId]},
        headMesh:{source:LinkedHead.source,assetId:LinkedHead.assetId,sha256:LinkedHead.sha256,vertices:headGeometry.vertexCount,triangles:headGeometry.triangleCount,transform:'archived Motor6D rig plus demo heading'},
        ownerHeadMesh:{source:TargetHead.source,sha256:TargetHead.sha256,vertices:targetHeadGeometry.vertexCount,triangles:targetHeadGeometry.triangleCount,displayed:false},
        faceTexture:{sha256:R6Face.sha256,loaded:faceLoaded},
        linkedSword:{assetId:SwordData.assetId,meshAssetId:SwordMesh.assetId,meshSha256:SwordMesh.sha256,triangleCount:swordGeometry.triangleCount,textureSha256:SwordData.textureSha256,textureLoaded:swordTextureLoaded,grip:'archived R6 attachment and public Tool Grip plus observed -90 degree R6 weld; not yet traced in WASM',attack:'source-script timing, animations, sounds and Blow checks adapted; training-dummy contacts and damage are approximations'},
        runningHeight:{source:runningHeight.source,branch:runningHeight.branch,plateTop:demoPlateTop,standingRootOffset,plateTarget:runningFloorTarget,contact:'demo approximation; full walking physics not recovered'},
        plateSize:[...plateSize],shapeSize:[...shapeSize],halfBounds:[...plateHalfBounds],
        canCollide:plate.canCollide,spawnDefaults:spawnProperties.snapshot(),
        materialCode:scene.baseplate.material,materialField4:partBytes.getFloat32(primitiveAddress+452,true),
        shapeKind:partBytes.getUint8(primitiveAddress+339),volumeAndCenter:Block.volumeAndCenter(plateSize),
        stagedFiles:assetFS.snapshot().inline.length,
        faceQueryChecks,
        stepScheduler:{demoHz,capSetting:stepView.getInt32(9031000,true),frames:stepStats.frames,totalTicks:stepStats.totalTicks,lastTicks:stepStats.lastTicks,retained:stepView.getFloat32(stepWorld+228,true),dropped:stepView.getFloat32(stepWorld+284,true)},
        keyboardTrace:{keyW:Keyboard.fromLoaderDomCode('KeyW'),logicalW:Keyboard.logicalFromCode(Keyboard.fromLoaderDomCode('KeyW')),usableQueueEntries:MainQueue.layout.usable},
        limitations:'renderer, movement, world and physics are approximations'
      }),
      reset
    };
    requestAnimationFrame(frame);
  } catch (err) {
    console.error(err);
    showError('The offline baseplate could not start: '+(err && err.message ? err.message : String(err)));
  }
})();
